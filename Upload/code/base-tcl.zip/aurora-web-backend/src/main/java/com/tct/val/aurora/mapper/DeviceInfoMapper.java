package com.tct.val.aurora.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tct.val.aurora.entity.DeviceInfo;

/**
 * @ClassName DeviceInfoMapper
 * @Description 设备信息mapper
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/15 17:28
 */
public interface DeviceInfoMapper extends BaseMapper<DeviceInfo> {
}
