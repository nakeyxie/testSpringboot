package com.tct.val.aurora.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

/**
 * @EnumName SwBuildType
 * @Description 软件编译类型
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/15 15:57
 */
@Slf4j
@Getter
public enum SwBuildType {

    //主版本
    APPLI( 1, "正式的 user 版本"),

    //每日一版
    DAILY(2, "DAILY"),

    //硬件出厂版本，最低，最核心版本
    MINI(3, "MINI"),

    //临时版本
    BLACK(4, "BLACK"),

    //验证硬件版本
    DRIVE_ONLY(5, "DRIVE_ONLY"),

    //认证版本
    CERTIFICATION(6, "CERTIFICATION"),

    //
    DEBUG(7, "DEBUG")

    ;

    SwBuildType(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    @EnumValue
    private Integer code;

    private String msg;

    public static SwBuildType valueOf(Integer code) {
        if(code == null){
            return null;
        }
        for (SwBuildType type : SwBuildType.values()) {
            if (type.code.equals(code)) {
                return type;
            }
        }
        log.error("枚举转换失败,code:{}", code);
        return null;
    }
}
