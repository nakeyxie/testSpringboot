package com.tct.val.aurora.service;



import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.tct.val.aurora.entity.Licence;


/**licence服务
 * @author R&D-VAL SZ nakey.xie
 * @date 2021/5/11 20:52
 */
public interface ILicenceService extends IService<Licence> {

    /**
     * @Description 根据机器ID查询授权记录
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021/6/8 17:51
     * @param machineId
     * @return com.tct.val.aurora.model.Licence
    */
    Licence getByMachineId(String machineId);


}
