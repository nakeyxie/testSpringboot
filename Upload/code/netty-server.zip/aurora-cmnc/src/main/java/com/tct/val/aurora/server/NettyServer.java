package com.tct.val.aurora.server;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;

/**
 * @ClassName nettyServer
 * @Description 连接服务
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/2 17:51
 */
// CommandLineRunner接口是在容器启动成功后的最后一步回调（类似开机自启动）
@Slf4j
public class NettyServer  implements CommandLineRunner {

    @Value("${con.port}")
    private int port;

    @Autowired
    private ServerInitializer serverInitializer;

    @Override
    public void run(String... args) throws Exception {
        //主线程组
        EventLoopGroup bossGroup = new NioEventLoopGroup();
        //工作线程组
        EventLoopGroup workGroup = new NioEventLoopGroup();
        try {
            ServerBootstrap server = new ServerBootstrap();
            server.group(bossGroup,workGroup)
                    .channel(NioServerSocketChannel.class)
                    .option(ChannelOption.SO_BACKLOG, 1024)
                    .handler(new LoggingHandler(LogLevel.DEBUG))
                    .childHandler(serverInitializer)
                    // 两小时内没有数据的通信时,TCP会自动发送一个活动探测数据报文
                    .childOption(ChannelOption.SO_KEEPALIVE, Boolean.TRUE);
            ChannelFuture future = server.bind(port).sync();
            log.info("netty服务启动,开始监听端口: {}", port);
            future.channel().closeFuture().sync();
        } catch (Exception e) {
            log.error("NettyServer---error:",e.getMessage(),e);
        } finally{
            //关闭主线程组
            bossGroup.shutdownGracefully();
            //关闭工作线程组
            workGroup.shutdownGracefully();
        }
    }
}
