package com.tct.val.aurora.server.handler;

import com.tct.val.aurora.protobuf.MessageBase;
import com.tct.val.aurora.server.IBusinessHandler;
import com.tct.val.aurora.server.annotation.Command;
import com.tct.val.aurora.util.ChannelUtil;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @ClassName DisConnectHandler
 * @Description 客户端断开连接处理
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/7 19:45
 */
@Component
@Slf4j
@Command(MessageBase.Message.CommandType.CLIENT_DISCONNECT)
@ChannelHandler.Sharable
public class ClientDisConnectHandler implements IBusinessHandler {

    @Autowired
    ChannelUtil channelUtil;

    @Override
    public void process(MessageBase.Message message, Channel channel) {
        channelUtil.channelReomved(channel);
    }
}
