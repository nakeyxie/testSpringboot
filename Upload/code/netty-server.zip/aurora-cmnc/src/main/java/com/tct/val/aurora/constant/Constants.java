package com.tct.val.aurora.constant;


/**
 * @ClassName Constants
 * @Description 通用常量信息
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021-6-15 20:17:37
 */
public class Constants
{
    /**
     * 连接认证字符常量
     */
    public static final String CONNECT_AUTH = "isSuccess";

    /**
     * 认证通过字符常量
     */
    public static final String AUTH_PASS = "checkAuth";


    /**
     * 客户端发送心跳内容
     */
    public static final String PING = "ping";

    /**
     * 服务器回应心跳内容
     */
    public static final String PONG = "pong";




}
