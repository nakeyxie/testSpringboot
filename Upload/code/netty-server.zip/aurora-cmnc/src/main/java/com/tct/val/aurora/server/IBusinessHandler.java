package com.tct.val.aurora.server;

import com.tct.val.aurora.protobuf.MessageBase;
import io.netty.channel.Channel;

/**
 * @Description 消息业务处理接口
 * @Author R&D-VAL SZ nakey.xie
 * @Date  2021/6/7 19:12
 * 对应不同的CommandType可以派生多个子类，具体交由各个处理器实现
 * @return
*/
public interface IBusinessHandler {
	
	void process(MessageBase.Message message, Channel channel);
	
}
