package com.tct.val.aurora.service.impl;


import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.tct.val.aurora.common.enums.OsType;
import com.tct.val.aurora.common.enums.RegionType;
import com.tct.val.aurora.common.enums.UsageState;
import com.tct.val.aurora.entity.ClientInfo;
import com.tct.val.aurora.entity.SysUser;
import com.tct.val.aurora.mapper.ClientInfoMapper;
import com.tct.val.aurora.service.IClientInfoService;
import com.tct.val.aurora.vo.req.ClientInfoPageQuery;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author R&D-VAL SZ nakey.xie
 * @date 2021-6-9 10:26:48
 */
@Service
public class ClientInfoServiceImpl extends ServiceImpl<ClientInfoMapper, ClientInfo> implements IClientInfoService {

    @Autowired
    public ClientInfoMapper clientInfoMapper;


    @Override
    public ClientInfo findByClientId(String clientId) {
        QueryWrapper<ClientInfo> query = new QueryWrapper<>();
        query.eq("client_id", clientId);
        return clientInfoMapper.selectOne(query);
    }

    @Override
    public void updateByClientId(ClientInfo clientInfo) {
        clientInfoMapper.update(clientInfo,
                new QueryWrapper<ClientInfo>().lambda().
                        eq(ClientInfo::getClientId,clientInfo.getClientId()));
    }

    @Override
    public IPage<ClientInfo> queryPage(ClientInfoPageQuery clientInfoPageQuery) {
        QueryWrapper<ClientInfo> query = new QueryWrapper();
        query.like(StringUtils.isNotEmpty(clientInfoPageQuery.getUserName()), "user_name", clientInfoPageQuery.getUserName())
                .like(StringUtils.isNotEmpty(clientInfoPageQuery.getPcName()), "pc_name", clientInfoPageQuery.getPcName())
                .eq(ObjectUtil.isNotNull(clientInfoPageQuery.getRegion()), "region", RegionType.valueOf(clientInfoPageQuery.getRegion()))
                .eq(ObjectUtil.isNotNull(clientInfoPageQuery.getOsType()), "os_type", OsType.valueOf(clientInfoPageQuery.getOsType()))
                .eq(ObjectUtil.isNotNull(clientInfoPageQuery.getUsageState()), "usage_state", UsageState.valueOf(clientInfoPageQuery.getUsageState()))
                .eq(ObjectUtil.isNotNull(clientInfoPageQuery.getConnected()), "connected", clientInfoPageQuery.getConnected())
                .orderByDesc("create_time");
        return clientInfoMapper.selectPage(clientInfoPageQuery, query);
    }
}
