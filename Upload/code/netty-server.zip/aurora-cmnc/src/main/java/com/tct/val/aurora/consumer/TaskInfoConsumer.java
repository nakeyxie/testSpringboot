package com.tct.val.aurora.consumer;

import com.rabbitmq.client.Channel;
import com.sun.media.jfxmedia.logging.Logger;
import com.tct.val.aurora.util.AckUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.stereotype.Component;


import java.util.Map;

/**
 * @ClassName ClinetInfoConsumer
 * @Description 消费消息
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/8 11:40
 */
@Slf4j
@Component
public class TaskInfoConsumer {

    @RabbitHandler
    @RabbitListener(queues = "taskQueue")
    public void processTaskMsg(Channel channel, String msg, Message message, @Headers Map<String,Object> map) {
        //处理消息
        log.info("处理消息:{}",msg);
        //下发消息
        //手工确认消费消息
        AckUtils.ack(channel,message,map);
    }


}
