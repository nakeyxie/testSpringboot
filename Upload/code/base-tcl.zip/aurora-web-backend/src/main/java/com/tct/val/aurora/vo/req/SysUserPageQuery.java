package com.tct.val.aurora.vo.req;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.tct.val.aurora.entity.SysUser;
import io.swagger.annotations.ApiOperation;
import lombok.Data;

import java.io.Serializable;

/**
 * @ClassName SysUserPageQuery
 * @Description 用户分页查询对象
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/5/31 17:31
 */
@Data
public class SysUserPageQuery extends Page<SysUser> {
    /**
     * 用户名
     */
    private String userName;

    /**
     * email
     */
    private String email;

    /**
     * 是否有效
     */
    private Boolean active;
}
