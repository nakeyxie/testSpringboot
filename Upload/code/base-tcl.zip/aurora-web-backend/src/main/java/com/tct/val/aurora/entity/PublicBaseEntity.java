package com.tct.val.aurora.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.io.Serializable;
import java.util.UUID;

/**
 * @author changyaowu
 */
@Data
public class PublicBaseEntity implements Serializable {

    private String id;

}
