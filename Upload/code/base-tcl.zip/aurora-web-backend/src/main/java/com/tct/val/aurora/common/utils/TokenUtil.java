package com.tct.val.aurora.common.utils;


import io.jsonwebtoken.*;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.userdetails.UserDetails;

import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import java.security.Key;
import java.util.Date;

/**
 * @author changyaowu
 */
public class TokenUtil {

    /**
     * 签名秘钥(唯一秘钥)
     */
    private static final String SECRET = "changyaowu@tcl.com";

    public static final String TOKEN_NAME = "Authorization";

    //1个小时后过期
    private static final long EXPIRATION = 60 * 60 * 1000;

    private static final Logger logger = LoggerFactory.getLogger(TokenUtil.class);


    /**
     * 生成token
     * @param userDetails
     * @return
     */
    public static String createJwtToken(UserDetails userDetails){
        return createJwtToken(userDetails.getUsername());
    }
    public static String createJwtToken(UserDetails userDetails,long expiration){
        String issuer = "www.wuchangyao.cn";
        String subject = "wuchangyao@live.com";

        return createJwtToken(userDetails.getUsername(),issuer,subject,expiration);
    }
    public static String createJwtToken(String userName){
        String issuer = "www.wuchangyao.cn";
        String subject = "wuchangyao@live.com";

        return createJwtToken(userName,issuer,subject,EXPIRATION);
    }
    /**
     * 生成token
     * @param username 用户名
     * @param issuer    该JWT的签发者，是否使用是可选的
     * @param subject   该JWT所面向的用户，是否使用是可选的；
     * @param ttlMillis 签发时间（有效时间，过期会报错）
     * @return token string
     */
    public static String createJwtToken(String username, String issuer, String subject, long ttlMillis){
        //签名算法，将token进行签名
        SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;
        //生成签发时间
        long nowMills = System.currentTimeMillis();

        Date now = new Date(nowMills);
        //通过秘钥签名JWT
        byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(SECRET);
        Key signingKey = new SecretKeySpec(apiKeySecretBytes,signatureAlgorithm.getJcaName());
        //创建token
        JwtBuilder builder = Jwts.builder().setId(username)
                .setIssuedAt(now)
                .setSubject(subject)
                .setIssuer(issuer)
                .signWith(signatureAlgorithm,signingKey);

        //添加过期时间
        if(ttlMillis >= 0 ){
            long expMillis = nowMills + ttlMillis;
            Date exp = new Date(expMillis);
            builder.setExpiration(exp);
        }
        return builder.compact();
    }


    public static boolean parseJWT(String token,UserDetails userDetails){

        Claims claims;

        try {
            claims = Jwts.parser()
                    .setSigningKey(DatatypeConverter.parseBase64Binary(SECRET))
                    .parseClaimsJws(token).getBody();

        }catch (ExpiredJwtException e){
            e.printStackTrace();
            return false;
        }

        return StringUtils.equals(claims.getId(),userDetails.getUsername());
    }

    public static String parseJWT(String token){
        Claims claims;

        try {
            claims = Jwts.parser()
                    .setSigningKey(DatatypeConverter.parseBase64Binary(SECRET))
                    .parseClaimsJws(token).getBody();

        }catch (Exception e){
            logger.error("Token校验失败",e);
            return null;
        }


        return claims.getId();
    }

}
