package com.tct.val.aurora.service.impl;


import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;


import com.tct.val.aurora.entity.SysUser;
import com.tct.val.aurora.mapper.SysUserMapper;
import com.tct.val.aurora.service.ISysUserService;
import com.tct.val.aurora.vo.req.SysUserPageQuery;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author R&D-VAL SZ changyaowu
 * @date 2021/5/11 20:52
 */
@Service
public class SysUserServiceImpl extends ServiceImpl<SysUserMapper, SysUser> implements ISysUserService {

    @Autowired
    public SysUserMapper userMapper;




    @Override
    public void update(SysUser user) {
        userMapper.updateById(user);
    }

    @Override
    public List<SysUser> findByAll() {
        return userMapper.selectList(null);
    }


    @Override
    public SysUser findByUserName(String userName) {
        QueryWrapper<SysUser> query = new QueryWrapper<>();
        query.eq("user_name",userName);
        return userMapper.selectOne(query);
    }

    @Override
    public void delUserByName(String userName) {
        Map<String,Object> deleteCodition = new HashMap<>();
        deleteCodition.put("user_name", userName);
        userMapper.deleteByMap(deleteCodition);
    }

    @Override
    public void updateByName(SysUser user) {
        userMapper.updateByName(user.getEmail(), user.getUserName());
    }

    @Override
    public IPage<SysUser> queryPage(SysUserPageQuery sysUserPageQuery) {
        QueryWrapper<SysUser> query = new QueryWrapper();
        query.like(StringUtils.isNotEmpty(sysUserPageQuery.getUserName()),"user_name",sysUserPageQuery.getUserName())
                .like(StringUtils.isNotEmpty(sysUserPageQuery.getEmail()),"email",sysUserPageQuery.getEmail())
                .eq(ObjectUtil.isNotNull(sysUserPageQuery.getActive()),"active",sysUserPageQuery.getActive())
                .orderByDesc("create_time");
        return userMapper.selectPage(sysUserPageQuery, query);
    }
}
