package com.tct.val.aurora.vo.resp;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.ToString;
import lombok.experimental.Accessors;
import org.springframework.security.core.GrantedAuthority;

import java.io.Serializable;
import java.util.Collection;

/**
 * @author
 */
@Data
@ToString
@Accessors(chain = true)
public class LicenceVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 是否新keyCode
     */
    private Boolean isNew;

    /**
     * keyCode验证码
     */
    private String keyCode;


}
