package com.tct.val.aurora;

import com.tct.val.aurora.server.NettyServer;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class AuroraCmncApplication {

    public static void main(String[] args) {
        SpringApplication.run(AuroraCmncApplication.class, args);
    }

    @Bean
    public NettyServer initServer(){
        return new NettyServer();
    }

}
