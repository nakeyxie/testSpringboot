package com.tct.val.aurora.vo.req;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.tct.val.aurora.entity.ClientInfo;
import com.tct.val.aurora.entity.DeviceInfo;
import lombok.Data;

/**
 * @ClassName SysUserPageQuery
 * @Description 客户端信息分页查询对象
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/5/31 17:31
 */
@Data
public class DeviceInfoPageQuery extends Page<DeviceInfo> {

    /**
     * 设备的 Serial Number
     */
    private String snNum;

    /**
     * 客户端唯一凭证ID（licenceId）
     */
    private String clientId;

    /**
     * PC机的计算机全名
     */
    private String pcName;
}
