package com.tct.val.aurora.common.utils;


import com.tct.val.aurora.vo.LdapUser;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.filter.EqualsFilter;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.naming.directory.Attribute;
import java.lang.reflect.Field;
import java.util.List;

/**
 * @author R&D-VAL SZ changyaowu
 * @date 2021/5/12 10:20
 */
@Slf4j
@Component
public class LdapSearchUtils {

    @Autowired
    private LdapTemplate template;

    @Value("${ldap.base}")
    private String base;

    public LdapUser searchByName(String name) {
        String filter = "(sAMAccountName=" + name + ")";
        return search(filter);
    }

    public LdapUser searchByMail(String mail) {
        String filter = "(mail= " + mail + ")";
        return search(filter);
    }

    /**
     *
     * @param username
     * @param password
     * @return
     */
    public boolean authenticate(String username,String password) {
        EqualsFilter filter = new EqualsFilter("sAMAccountName", username);
        boolean isSuccess = false;
        try {
            isSuccess = template.authenticate(base, filter.toString(), password);
        } catch (Exception e) {
            log.error("authenticate-fail!",e);
        }
        return isSuccess;
    }


    public LdapUser search(String filter) {
        List<LdapUser> users = template.search(base, filter, (AttributesMapper<LdapUser>) attributes -> {
            LdapUser user = new LdapUser();

            Field[] fs = user.getClass().getDeclaredFields();
            Field f;
            Attribute attribute;
            for (int i = 0; i < fs.length; i++) {
                f = fs[i];
                f.setAccessible(true);
                attribute = attributes.get(f.getName());
                if (null != attribute) {
                    try {
                        f.set(user, attribute.get().toString());
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    }
                }
            }

            return user;
        });
        return CollectionUtils.isEmpty(users) ? null : users.get(0);
    }



}
