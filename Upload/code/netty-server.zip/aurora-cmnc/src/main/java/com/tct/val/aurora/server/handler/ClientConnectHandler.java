package com.tct.val.aurora.server.handler;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.tct.val.aurora.constant.Constants;
import com.tct.val.aurora.constant.MqConstants;
import com.tct.val.aurora.protobuf.MessageBase;
import com.tct.val.aurora.server.IBusinessHandler;
import com.tct.val.aurora.server.MQSender;
import com.tct.val.aurora.server.annotation.Command;
import com.tct.val.aurora.util.ChannelUtil;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandler;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @ClassName ConnectHandler
 * @Description 客户端连接消息处理
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/7 19:44
 */
@Component
@Slf4j
@ChannelHandler.Sharable
@Command(MessageBase.Message.CommandType.CLIENT_CONNECT)
public class ClientConnectHandler implements IBusinessHandler {

    @Autowired
    private ChannelUtil channelUtil;

    @Autowired
    private MQSender mqSender;
    @Override
    public void process(MessageBase.Message message, Channel channel) {
        String content = message.getContent();
        log.info("收到客户端连接请求:{}", message.getContent());
        String clientId = channelUtil.channelAuthentication(channel, message);
        MessageBase.Message response = MessageBase.Message.newBuilder()
                .setCmd(MessageBase.Message.CommandType.CLIENT_CONNECT)
                .build();
        JSONObject object = new JSONObject();
        if (StringUtils.isNotBlank(clientId)) {
            //认证成功
            object.put(Constants.CONNECT_AUTH,true);
            content = addIpAddr(channel,content);
            //发送mq消息到web后台
            mqSender.sendMessage(MqConstants.Exchange.CLIENT_EXCHANGE,MqConstants.RouteKey.ROUTING_KEY_CLIENT_CONNECT,content);
        } else {
            //认证失败
            object.put(Constants.CONNECT_AUTH,false);
        }
        response = response.toBuilder().setContent(object.toJSONString()).build();
        channelUtil.sendMsg(channel, response);
    }

    /**
     * @Description 添加ip信息
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021/6/9 13:10
     * @param channel
     * @param content
     * @return java.lang.String
    */
    private String addIpAddr(Channel channel, String content) {
        String ip = ChannelUtil.getIp(channel);
        JSONObject obj = JSON.parseObject(content);
        obj.put("ipAddr",ip);
        return JSON.toJSONString(obj);
    }
}
