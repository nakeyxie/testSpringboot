package com.tct.val.aurora.common.enums;

/**
 * @ClassName UserActiveEnum
 * @Description 账户的可用状态枚举
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/5/27 17:38
 */
public enum UserActiveEnum {

    ENABLE(1,"可用"),

    DISABLE(0,"禁用");


    private int code;

    private String msg;

    UserActiveEnum(int code, String msg){
        this.code =code;
        this.msg = msg;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
