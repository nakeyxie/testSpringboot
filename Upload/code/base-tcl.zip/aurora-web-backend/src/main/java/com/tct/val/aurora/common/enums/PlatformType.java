package com.tct.val.aurora.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

/**
 * @EnumName PlatformType
 * @Description 芯片的平台类型
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/15 16:08
 */
@Slf4j
@Getter
public enum PlatformType {

    QCT(1, "高通"),

    MTK(2, "联发科"),

    SPRD(3, "展讯")

    ;

    PlatformType(Integer code, String msg){
        this.code = code;
        this.msg = msg;
    }

    @EnumValue
    private Integer code;

    private String msg;

    public static PlatformType valueOf(Integer code) {
        if(code == null){
            return null;
        }
        for (PlatformType type : PlatformType.values()) {
            if (type.code.equals(code)) {
                return type;
            }
        }
        log.error("枚举转换失败,code:{}", code);
        return null;
    }


}
