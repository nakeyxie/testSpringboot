package com.tct.val.aurora.controller;


import com.tct.val.aurora.vo.resp.ResponseMessage;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @author R&D-VAL SZ changyaowu
 * @date 2021/5/12 13:14
 */
@Controller
@RequestMapping("admin")
public class AdminController {

    @PostMapping("hello")
    @ResponseBody
    public ResponseMessage<Object> hello() {
        return new ResponseMessage<>("hello");
    }
}
