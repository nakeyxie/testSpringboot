package com.tct.val.aurora.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.filter.EqualsFilter;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @author changyaowu
 */
@Controller
@RequestMapping("/system")
public class LoginController {

    @Autowired
    private LdapTemplate ldapTemplate;

    @PostMapping("/login")
    @ResponseBody
    public boolean login(String username, String password) {
        System.out.println(username + " : " + password);
        EqualsFilter filter = new EqualsFilter("sAMAccountName",username);
        return ldapTemplate.authenticate("DC=ta-mp,DC=com",filter.toString(),password);
    }
}
