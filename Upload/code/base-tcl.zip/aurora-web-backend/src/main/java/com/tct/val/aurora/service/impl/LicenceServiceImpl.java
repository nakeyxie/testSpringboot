package com.tct.val.aurora.service.impl;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import com.tct.val.aurora.entity.Licence;
import com.tct.val.aurora.mapper.LicenceMapper;
import com.tct.val.aurora.service.ILicenceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author R&D-VAL SZ changyaowu
 * @date 2021/5/11 20:52
 */
@Service
public class LicenceServiceImpl extends ServiceImpl<LicenceMapper, Licence> implements ILicenceService {

    @Autowired
    public LicenceMapper licenceMapper;


    @Override
    public Licence getByMachineId(String machineId) {
        QueryWrapper<Licence> query = new QueryWrapper<>();
        query.eq("machine_id",machineId);
        return licenceMapper.selectOne(query);
    }
}
