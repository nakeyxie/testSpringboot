package com.tct.val.aurora.server.handler;

import com.tct.val.aurora.constant.MqConstants;
import com.tct.val.aurora.protobuf.MessageBase;
import com.tct.val.aurora.server.IBusinessHandler;
import com.tct.val.aurora.server.MQSender;
import com.tct.val.aurora.server.annotation.Command;
import com.tct.val.aurora.util.ChannelUtil;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @ClassName DisConnectHandler
 * @Description 设备断开连接处理
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021-6-15 20:13:47
 */
@Component
@Slf4j
@Command(MessageBase.Message.CommandType.DEVICE_DISCONNECT)
@ChannelHandler.Sharable
public class DeviceDisConnectHandler implements IBusinessHandler {

    @Autowired
    private MQSender mqSender;

    @Override
    public void process(MessageBase.Message message, Channel channel) {
        String content = message.getContent();
        log.info("收到客户端的设备断开连接消息：{}", content);
        try {
            //发送mq消息到web后台
            mqSender.sendMessage(MqConstants.Exchange.DEVICE_EXCHANGE, MqConstants.RouteKey.ROUTING_KEY_DEVICE_DISCONNECT, content);
            log.info("发送设备断开连接消息成功!");
        } catch (Exception e) {
            log.error("发送设备断开连接消息失败！msg:{}", e.getMessage(), e);
        }
    }
}
