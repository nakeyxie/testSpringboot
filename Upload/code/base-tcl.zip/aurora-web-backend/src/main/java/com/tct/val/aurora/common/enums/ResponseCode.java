package com.tct.val.aurora.common.enums;

/**
 * @author changyaowu
 * 返回数据基类，快速调用
 *  *  return ResponseCode.success();
 *  *  return ResponseCode.success(data);
 *  *  return ResponseCode.success().data(data);
 *  *  return ResponseCode.error(code, message);
 *  *  return ResponseCode.error(code, message, data);
 *  *  return ResponseCode.error(code, message).data(data);
 */

public enum ResponseCode {
    //成功
    SUCCESS(0,"success"),

    //失败
    FAIL(-1,"common fail"),

    //新建数据
    CREATED(201),
    //无内容
    NO_CONTENT(204),

    PARAM_FAIL(400,"参数错误"),
    ACCESS_DENIED(403,"权限不足"),
    MOBILE_REPEAT(406,"手机号码重复"),
    ICARD_REPEAT(407,"身份证号码重复"),
    JOBNUMBER_CREATE_FAIL(408,"工号创建失败!"),
    ACCOUNT_CREATE_FAIL(409,"帐号创建失败!"),
    EMAIL_CREATE_FAIL(410,"邮箱创建失败!"),
    EMAIL_DEL_FAIL(411,"邮箱删除失败!"),
    TIME_ERROR(412,"时间错误"),
    USER_NOT_FOUND(440,"找不到用户信息"),
    NON_LOGIN(441,"未登陆"),
    NON_ASSIGNEE(442,"无处理人"),
    DEPT_NOT_FOUND(443,"找不到部门信息"),
    DATA_REPEAT(444,"数据重复"),
    DATA_EXIST(445,"数据已存在"),
    DATA_NOT_EXIST(446,"数据不存在"),
    DATA_ERROR(446,"数据错误"),
    DATA_EXCEPT(447,"数据异常"),

    USER_ACCOUNT_EXPIRED(450,"账号过期"),
    USER_CREDENTIALS_ERROR(451,"密码错误"),
    USER_CREDENTIALS_EXPIRED(452,"密码过期"),
    USER_ACCOUNT_DISABLE(453,"账号不可用"),
    USER_ACCOUNT_LOCKED(454,"用户锁定"),
    USER_ACCOUNT_NOT_EXIST(455,"用户不存在"),
    USER_ACCOUNT_USE_BY_OTHERS(456,"账号在其他地方登录"),

    SERVICE_EXCEPTION(500,"服务异常"),
    BUSINESS_EXCEPTIONS(3002,"业务异常");


    private final int code;
    private final String message;

    ResponseCode(int code){
        this.code = code;
        this.message = "";
    }
    ResponseCode(int code, String message){
        this.code = code;
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
