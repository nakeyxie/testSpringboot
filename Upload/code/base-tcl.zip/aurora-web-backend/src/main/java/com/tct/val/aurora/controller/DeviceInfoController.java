package com.tct.val.aurora.controller;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.tct.val.aurora.common.exception.BusinessException;
import com.tct.val.aurora.entity.ClientInfo;
import com.tct.val.aurora.entity.DeviceInfo;
import com.tct.val.aurora.service.IClientInfoService;
import com.tct.val.aurora.service.IDeviceInfoService;
import com.tct.val.aurora.vo.req.ClientInfoPageQuery;
import com.tct.val.aurora.vo.req.DeviceInfoPageQuery;
import com.tct.val.aurora.vo.resp.ResponseMessage;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


/**
 * @ClassName etstController
 * @Description 设备信息管理
 * @Author R&D-VAL SZ nakey.xie
 * @Date2021-6-15 17:35:49
 */
@Api("设备信息管理")
@RestController
@RequestMapping("/device")
public class DeviceInfoController {


    @Autowired
    IDeviceInfoService deviceInfoService;

    /**
     * 分页查询客户端信息
     */
    @ApiOperation("分页查询客户端信息")
    @GetMapping("/page")
    public ResponseMessage queryPage(DeviceInfoPageQuery deviceInfoPageQuery){
        IPage<DeviceInfo> deviceInfoPage = deviceInfoService.queryPage(deviceInfoPageQuery);
        return ResponseMessage.success(deviceInfoPage);

    }


    /**
     * 分页查询客户端信息
     */
    @ApiOperation("根据clientId查询设备列表")
    @GetMapping("/list")
    public ResponseMessage queryListByClient(String clientId) {
        if (StringUtils.isBlank(clientId)) {
            throw new BusinessException("客户端ID为空!");
        }
        List<DeviceInfo> devices = deviceInfoService.queryListByClientId(clientId);
        return ResponseMessage.success(devices);
    }



}
