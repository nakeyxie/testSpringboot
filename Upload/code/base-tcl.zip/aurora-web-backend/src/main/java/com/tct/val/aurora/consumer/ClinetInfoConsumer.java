package com.tct.val.aurora.consumer;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.rabbitmq.client.Channel;
import com.tct.val.aurora.common.constant.MqConstants;
import com.tct.val.aurora.common.utils.AckUtils;
import com.tct.val.aurora.entity.ClientInfo;
import com.tct.val.aurora.service.IClientInfoService;
import com.tct.val.aurora.service.IDeviceInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * @ClassName ClinetInfoConsumer
 * @Description 客户端消息订阅
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/8 11:40
 */
@Slf4j
@Component
public class ClinetInfoConsumer {

    @Autowired
    IClientInfoService clientInfoService;

    @Autowired
    IDeviceInfoService deviceInfoService;

    /**
     * @Description 客户端连接成功后，接收客户端信息
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021/6/8 13:41
     * @return void
    */
    @RabbitHandler
    @RabbitListener(queues = MqConstants.Queue.CLIENT_CONNECT_QUEQUE)
    public void processConnect(Channel channel, String msg, Message message, @Headers Map<String, Object> map) {
        log.info("订阅客户端连接消息:{}", msg);
        try {
            ClientInfo clientInfo = JSON.parseObject(msg, ClientInfo.class);
            clientInfo.setConnected(Boolean.TRUE);
            String clientId = clientInfo.getClientId();
            ClientInfo existClient = clientInfoService.findByClientId(clientId);
            if (ObjectUtil.isNotNull(existClient)) {
                clientInfo.setId(existClient.getId());
                clientInfoService.updateById(clientInfo);
            } else {
                clientInfoService.save(clientInfo);
            }
        } catch (Exception e) {
            log.error("处理客户端连接消息异常", e);
        }
        AckUtils.ack(channel, message, map);
    }

    /**
     * @Description 监听客户端断开连接的消息
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021/6/15 15:30
     * @param channel
     * @param msg
     * @param message
     * @param map
     * @return void
    */
    @RabbitHandler
    @RabbitListener(queues = MqConstants.Queue.CLIENT_DISCONNECT_QUEQUE)
    public void processDisConnect(Channel channel, String msg, Message message, @Headers Map<String,Object> map) {
        log.info("订阅客户端断开连接消息:{}", msg);
        if (StrUtil.isNotBlank(msg)) {
            ClientInfo clientInfo = new ClientInfo();
            clientInfo.setClientId(msg);
            clientInfo.setConnected(Boolean.FALSE);
            clientInfoService.updateByClientId(clientInfo);
            //设置客户端上的设备也为断开连接
            deviceInfoService.disconnectByClientId(msg);
        }
        AckUtils.ack(channel,message,map);
    }
}
