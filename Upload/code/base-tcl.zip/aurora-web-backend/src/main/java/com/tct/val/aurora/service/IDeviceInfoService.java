package com.tct.val.aurora.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.tct.val.aurora.entity.ClientInfo;
import com.tct.val.aurora.entity.DeviceInfo;
import com.tct.val.aurora.entity.SysUser;
import com.tct.val.aurora.vo.req.ClientInfoPageQuery;
import com.tct.val.aurora.vo.req.DeviceInfoPageQuery;

import java.util.List;

/**
 * @InterfaceName IDeviceInfoService
 * @Description 设备信息服务
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/15 17:30
 */
public interface IDeviceInfoService extends IService<DeviceInfo> {

    /**
     * @Description 分页查询设备信息
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021-6-15 17:33:52
     * @param deviceInfoPageQuery
     * @return
     */
    IPage<DeviceInfo> queryPage(DeviceInfoPageQuery deviceInfoPageQuery);

    /**
     * @Description 根据设备唯一号查询设备信息
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021/6/16 10:35
     * @param snNum
     * @return com.tct.val.aurora.entity.DeviceInfo
    */
    DeviceInfo findBySnNum(String snNum);

    /**
     * @Description 根据设备唯一号更新设备连接状态
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021/6/16 10:44
     * @param deviceInfo
     * @return void
    */
    void updateBySnNum(DeviceInfo deviceInfo);

    /**
     * @Description 根据客户端ID断开连接
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021/6/16 14:14
     * @param clientId
     * @return void
    */
    void disconnectByClientId(String clientId);

    /**
     * @Description 根据客户端ID查询设备列表
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021/6/16 14:50
     * @param clientId
     * @return java.util.List<com.tct.val.aurora.entity.DeviceInfo>
    */
    List<DeviceInfo> queryListByClientId(String clientId);
}
