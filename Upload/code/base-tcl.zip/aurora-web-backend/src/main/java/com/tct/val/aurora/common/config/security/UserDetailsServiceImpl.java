package com.tct.val.aurora.common.config.security;



import com.tct.val.aurora.common.enums.RoleEnum;
import com.tct.val.aurora.common.exception.BusinessException;
import com.tct.val.aurora.entity.SysUser;
import com.tct.val.aurora.service.ISysUserService;
import com.tct.val.aurora.vo.LoginUser;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.HashSet;
import java.util.Set;

/**
 * @Author: wcy
 * @Date: 2020/9/18 3:14 下午
 */
public class UserDetailsServiceImpl implements UserDetailsService {

    private static final Logger log = LoggerFactory.getLogger(UserDetailsServiceImpl.class);

    @Autowired
    private ISysUserService userService;

    /**
     *
     * @param username
     * @return
     * @throws UsernameNotFoundException
     * String username：用户名
     * String password： 密码
     * boolean enabled： 账号是否可用
     * boolean accountNonExpired：账号是否过期
     * boolean credentialsNonExpired：密码是否过期
     * boolean accountNonLocked：账号是否锁定
     * Collection<? extends GrantedAuthority> authorities)：用户权限列表
     */
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        if(StringUtils.isBlank(username)){
            throw new BusinessException("账号不能为空");
        }

        SysUser user = userService.findByUserName(username);

        if(null == user){
            log.info("登录用户：{} 不存在.", username);
            throw new InternalAuthenticationServiceException("用户不存在");
        }
        //根据用户名查询用户对应角色的所有权限 todo
        Set<String> permissions = new HashSet<>();

        permissions.add(RoleEnum.ROLE_USER.getKey());
        if(Boolean.TRUE.equals(user.getManager())) {
            permissions.add(RoleEnum.ROLE_ADMIN.getKey());
        }

        return new LoginUser(user, permissions);
        //return new LoginUser(user, permissionService.getMenuPermission(user));

        /*return new User(username,
                user.getPassword(),
                // 这里添加用户权限
                list);*/
    }
}
