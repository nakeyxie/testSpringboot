package com.tct.val.aurora.server;

import com.tct.val.aurora.protobuf.MessageBase;
import io.netty.channel.Channel;

/**
 * @InterfaceName IDispatcher
 * @Description 处理器分发接口
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/7 19:17
 */
public interface IDispatcher {

    /**
     * @Description 消息分发
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021/6/7 19:59
     * @param message
     * @param channel
     * @return void
    */
    void dispatcher(MessageBase.Message message, Channel channel);

}
