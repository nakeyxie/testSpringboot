package com.tct.val.aurora.service.impl;


import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.tct.val.aurora.entity.DeviceInfo;
import com.tct.val.aurora.mapper.DeviceInfoMapper;
import com.tct.val.aurora.service.IDeviceInfoService;
import com.tct.val.aurora.vo.req.DeviceInfoPageQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author R&D-VAL SZ nakey.xie
 * @date 2021-6-15 17:31:44
 */
@Service
public class DeviceInfoServiceImpl extends ServiceImpl<DeviceInfoMapper, DeviceInfo> implements IDeviceInfoService {

    @Autowired
    public DeviceInfoMapper deviceInfoMapper;



    @Override
    public IPage<DeviceInfo> queryPage(DeviceInfoPageQuery deviceInfoPageQuery) {
        return null;
    }

    @Override
    public DeviceInfo findBySnNum(String snNum) {
        QueryWrapper<DeviceInfo> query = new QueryWrapper<>();
        query.eq("sn_num", snNum);
        return deviceInfoMapper.selectOne(query);
    }

    @Override
    public void updateBySnNum(DeviceInfo deviceInfo) {
        deviceInfoMapper.update(deviceInfo, new QueryWrapper<DeviceInfo>().lambda()
        .eq(DeviceInfo::getSnNum, deviceInfo.getSnNum()));
    }

    @Override
    public void disconnectByClientId(String clientId) {
        DeviceInfo deviceInfo = new DeviceInfo();
        deviceInfo.setConnected(Boolean.FALSE);
        deviceInfoMapper.update(deviceInfo,
                Wrappers.<DeviceInfo>lambdaUpdate().eq(DeviceInfo::getClientId, clientId));
    }

    @Override
    public List<DeviceInfo> queryListByClientId(String clientId) {
        return deviceInfoMapper.selectList(Wrappers.<DeviceInfo>lambdaQuery().eq(DeviceInfo::getClientId, clientId));
    }
}
