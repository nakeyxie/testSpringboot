package com.tct.val.aurora.entity;

import com.tct.val.aurora.common.enums.DeviceUsageState;
import com.tct.val.aurora.common.enums.OsType;
import com.tct.val.aurora.common.enums.PlatformType;
import com.tct.val.aurora.common.enums.SwBuildType;
import lombok.Data;

/**
 * @ClassName DeviceInfo
 * @Description 设备信息实体
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/15 16:37
 */
@Data
public class DeviceInfo  extends  BaseEntity{

    /**
     * PC机客户端ID
     */
    private String clientId;

    /**
     * 设备的 Serial Number
     */
    private String snNum;

    /**
     * 芯片的平台类型
     */
    private PlatformType platformType;

    /**
     * 操作系统的类型
     */
    private OsType osType;

    /**
     * 操作系统的版本号
     */
    private String  osVersion;

    /**
     * Ram 内存大小
     */
    private Integer ramSize;

    /**
     * ROM 存储大小
     */
    private Integer romSize;

    /**
     * 屏幕分辨率的高度
     */
    private Integer screenHeight;

    /**
     * 屏幕分辨率的宽度
     */
    private Integer screenWidth;

    /**
     * 软件编译的类型
     */
    private SwBuildType swBuildType;

    /**
     * 软件版本
     */
    private String swVersion;

    /**
     * perso 名称
     */
    private String perso;

    /**
     * perso 版本
     */
    private String persoVersion;

    /**
     * 项目名称
     */
    private String projectName;

    /**
     * 产品名称
     */
    private String productName;

    /**
     * marketingName
     */
    private String marketingName;

    /**
     * brand
     * ro.product.brand
     */
    private String brand;

    /**
     * 判断与 adb 的连接状态
     */
    private Boolean connected;

    /**
     * 设备是否共享使用
     */
    private Boolean share;

    /**
     * DUT 设备的使用状态
     */
    private DeviceUsageState usageState;
}
