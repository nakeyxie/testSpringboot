package com.tct.val.aurora.entity;

import lombok.Data;

import javax.validation.constraints.NotBlank;


/**
 * @author changyaowu
 */
@Data
public class SysUser extends BaseEntity{

    /**
     * 用户名
     */
    @NotBlank(message = "userName不能为空")
    private String userName;

    /**
     * 密码
     */
    @NotBlank(message = "密码不能为空")
    private String password;

    /**
     * email
     */
    @NotBlank(message = "邮箱不能为空")
    private String email;

    /**
     * 是否有效
     */
    private Boolean active;

    /**
     * 是否管理员
     */
    private Boolean manager;

    /**
     * 头像
     */
    private byte[] icon;

    public SysUser() {
    }

    public SysUser(String userName, String password, String email) {
        this.userName = userName;
        this.password = password;
        this.email = email;
    }
}
