package com.tct.val.aurora.common.enums;

/**
 * @author R&D-VAL SZ changyaowu
 * @date 2021/5/12 19:43
 */
public enum RoleEnum {
    // 管理
    ROLE_ADMIN("role_admin","管理员"),
    // 普通
    ROLE_USER("role_user","普通用户");

    private String key;
    private String name;

    RoleEnum(String key, String name) {
        this.key = key;
        this.name = name;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
