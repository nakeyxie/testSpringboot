package com.tct.val.aurora.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import com.tct.val.aurora.entity.SysUser;
import org.apache.ibatis.annotations.Param;

/**
 * @InterfaceName SysUserMapper
 * @Description 系统用户dao
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/5/31 10:02
 */
public interface SysUserMapper extends BaseMapper<SysUser> {

    int updateByName(@Param("email") String email, @Param("userName") String useName);

    Integer deleteByIdWithFill(SysUser user);

}
