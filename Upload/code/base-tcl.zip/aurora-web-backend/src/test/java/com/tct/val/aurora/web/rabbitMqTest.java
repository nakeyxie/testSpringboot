package com.tct.val.aurora.web;

import com.tct.val.aurora.service.MQSender;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @ClassName rabbitMqTest
 * @Description 测试mq消息
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/8 13:23
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class rabbitMqTest {

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Autowired
    private MQSender mqSender;


    @Test
    public void send(){
        String msg ="任务下发!";
        rabbitTemplate.convertAndSend("taskExchange","task.send",msg);
        System.out.println("下发成功!");
    }


    /**
     * @Description 测试消息到达exchange的回调机制
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021/6/10 13:27
     * @param
     * @return void
    */
    @Test
    public void testConfirm(){
        String msg ="我没到exchange1";
        mqSender.sendMessage("testExchange","123",msg,new CorrelationData("753"));
        System.out.println("发送消息1完毕!");
        String msg2 ="我没到exchange2";
        mqSender.sendMessage("testExchange","123",msg2,new CorrelationData("951"));
        System.out.println("发送消息2完毕!");

        String msg3 ="我到exchange了";
        mqSender.sendMessage("taskExchange","task.send",msg3,new CorrelationData("8856"));
        System.out.println("发送消息3完毕!");
        String msg4 ="我到exchange了";
        mqSender.sendMessage("taskExchange","task.send",msg4,new CorrelationData("9981"));
        System.out.println("发送消息4完毕!");

    }

    /**
     * @Description 测试消息到达队列回调
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021/6/10 13:36
     * @param
     * @return void
    */
    @Test
    public void testCallBacke(){
        String msg1 ="我到exchange了,没到队列";
        mqSender.sendMessage("taskExchange","123",msg1, new CorrelationData("7867"));
        System.out.println("消息1发送完毕!");
        String msg2 = "我已安全到达队列";
        mqSender.sendMessage("taskExchange","task.send",msg2,new CorrelationData("123456"));
        System.out.println("消息2发送完毕!");

        String msg3 ="我到exchange了,没到队列3232";
        mqSender.sendMessage("taskExchange","456",msg3, new CorrelationData("9999"));
        System.out.println("消息3发送完毕!");

    }
}
