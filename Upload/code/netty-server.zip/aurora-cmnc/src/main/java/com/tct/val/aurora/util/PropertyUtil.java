package com.tct.val.aurora.util;

import cn.hutool.core.io.FileUtil;
import cn.hutool.setting.Setting;
import io.netty.util.CharsetUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @ClassName PropertyUtil
 * @Description 配置文件工具
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/7 14:48
 */
@Component
@Slf4j
public class PropertyUtil {

    @Value("${setting.locations}")
    private  String path;


    public int getVersion() {
        try {
            Setting setting = new Setting(FileUtil.touch(path), CharsetUtil.UTF_8, true);
            //Setting setting = new Setting(FileUtil.touch("D:\\properties\\version.setting"), CharsetUtil.UTF_8, true);
            setting.load();

            String version = setting.get("version");
            return Integer.valueOf(version);
        } catch (Exception e) {
            log.error("获取版本失败:{}", e.getMessage(), e);
            return -1;
        }
    }


}
