package com.tct.val.aurora.common.config.security;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;


/**
 * @Author: wcy
 * @Date: 2020/9/17 8:56 上午
 */
@Configuration
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
    @Autowired
    private CustomizeAuthenticationEntryPoint authenticationEntryPoint;
    @Autowired
    private CustomizeLogoutSuccessHandler logoutSuccessHandler;
    @Autowired
    private CustomizeAuthenticationFailureHandler authenticationFailureHandler;
    @Autowired
    private CustomizeAuthenticationSuccessHandler authenticationSuccessHandler;

    @Autowired
    private CustomizeAccessDeniedHandler accessDeniedHandler;
    @Autowired
    private LoginAuthenticationProvider authenticationProvider;

    @Autowired
    private JwtAuthenticationTokenFilter authenticationTokenFilter;




    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        // 设置默认的加密方式（强hash方式加密）
        return new BCryptPasswordEncoder();
    }



    @Bean
    public CorsFilter corsFilter() {
        CorsConfiguration config = new CorsConfiguration();
        //  你需要跨域的地址  注意这里的 127.0.0.1 != localhost
        // * 表示对所有的地址都可以访问
        config.addAllowedOrigin("*");
        //  跨域的请求头
        config.addAllowedHeader("*");
        //  跨域的请求方法
        config.addAllowedMethod("*");
        // 加上了这一句，大致意思是可以携带 cookie
        // 最终的结果是可以 在跨域请求的时候获取同一个 session
        // config.setAllowCredentials(true);
        config.setAllowCredentials(false);

        UrlBasedCorsConfigurationSource configSource = new UrlBasedCorsConfigurationSource();
        configSource.registerCorsConfiguration("/**", config);
        return new CorsFilter(configSource);
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {

        //关闭跨域验证&关闭csrf防护(因为不使用session)
        http.cors().and().csrf().disable();

                // 配置拦截规则
                //开发阶段接口测试(开放swagger)
        http.authorizeRequests()
                .antMatchers(
                        "/swagger**",
                        "/webjars/**",
                        "/favicon.ico",
                        "/swagger-resources/**",
                        "/webjars/",
                        "/v2/**",
                        "/error",
                        "/csrf"
                ).permitAll()
                .anyRequest().authenticated()

                .and()
                // 登录配置
                .formLogin()
                .successHandler(authenticationSuccessHandler)
                .failureHandler(authenticationFailureHandler)

                // 退出配置
                .and()
                .logout()
                .logoutSuccessHandler(logoutSuccessHandler).deleteCookies("JSESSIONID")

                // 禁用session//基于token，不需要session
                .and()
                .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)


                // 异常处理器(未登录 and 权限不足)
                .and()
                .exceptionHandling()
                //定义认证失败处理类
                .authenticationEntryPoint(authenticationEntryPoint)
                //访问拒绝处理
                .accessDeniedHandler(accessDeniedHandler)

                // 添加JWT filter
                .and()
                .addFilterBefore(authenticationTokenFilter, UsernamePasswordAuthenticationFilter.class)
        ;


    }


    @Bean
    @Override
    protected UserDetailsService userDetailsService() {
        return new UserDetailsServiceImpl();
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.authenticationProvider(authenticationProvider);
    }

}
