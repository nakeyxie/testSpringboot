package com.tct.val.aurora.common.exception;

import com.tct.val.aurora.vo.resp.ResponseMessage;
import com.tct.val.aurora.common.enums.ResponseCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.converter.HttpMessageConversionException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;


/**
 * @ClassName BusinessException
 * @Description 全局异常处理
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021-5-27 14:24:56
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    //处理自定义的异常
    @ExceptionHandler(BusinessException.class)
    @ResponseBody
    public Object businessExceptionHandler(BusinessException e){
        log.error("businessException :{}",e.getMessage(),e);
        return ResponseMessage.error(e.getCode(), e.getMessage());
    }

    /**
     *  校验错误拦截处理
     *
     * @param exception 错误信息集合
     * @return 错误信息
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseBody
    public Object validationBodyException(MethodArgumentNotValidException exception) {
        BindingResult result = exception.getBindingResult();
        StringBuffer errorMsg = new StringBuffer("请填写正确信息:");
        if (result.hasErrors()) {
            List<ObjectError> errors = result.getAllErrors();
            errors.forEach(p -> {
                FieldError fieldError = (FieldError) p;
                log.error("Data check failure : object{" + fieldError.getObjectName() + "},field{" + fieldError.getField() +
                        "},errorMessage{" + fieldError.getDefaultMessage() + "}");
                errorMsg.append("[").append(fieldError.getDefaultMessage()).append("]");
            });
        }
        return ResponseMessage.error(errorMsg.toString());
    }

    /**
     * 参数类型转换错误
     *
     * @param exception 错误
     * @return 错误信息
     */
    @ExceptionHandler(HttpMessageConversionException.class)
    @ResponseBody
    public Object parameterTypeException(HttpMessageConversionException exception){
        log.error(exception.getCause().getLocalizedMessage() , exception);
        return ResponseMessage.error("类型转换错误");

    }


    //其他未处理的异常
    @ExceptionHandler(Exception.class)
    @ResponseBody
    public Object exceptionHandler(Exception e){
        log.error("exception :{}",e);
        return ResponseMessage.error(ResponseCode.FAIL.getCode(), "系统异常:"+e.getMessage());
    }
}
