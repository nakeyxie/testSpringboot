package com.tct.val.aurora.server.handler;

import com.tct.val.aurora.constant.MqConstants;
import com.tct.val.aurora.protobuf.MessageBase;
import com.tct.val.aurora.server.IBusinessHandler;
import com.tct.val.aurora.server.MQSender;
import com.tct.val.aurora.server.annotation.Command;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @ClassName UploadDeviceHandler
 * @Description 设备连接消息处理
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/7 19:46
 */
@Slf4j
@Component
@Command({MessageBase.Message.CommandType.DEVICE_CONNECT})
@ChannelHandler.Sharable
public class DeviceConnectHandler implements IBusinessHandler {

    @Autowired
    private MQSender mqSender;

    @Override
    public void process(MessageBase.Message message, Channel channel) {
        String content = message.getContent();
        log.info("收到客户端的设备连接消息：{}", content);
        try {
            //发送mq消息到web后台
            mqSender.sendMessage(MqConstants.Exchange.DEVICE_EXCHANGE,MqConstants.RouteKey.ROUTING_KEY_DEVICE_ADD_UPDATE,content);
            log.info("发送设备连接消息成功!");
        } catch (Exception e) {
           log.error("发送连接设备消息失败！msg:{}",e.getMessage(),e);
        }
    }
}
