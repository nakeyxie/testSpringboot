package com.tct.val.aurora.client;

import com.alibaba.fastjson.JSON;
import com.fasterxml.jackson.databind.deser.std.JsonNodeDeserializer;
import com.tct.val.aurora.protobuf.MessageBase;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import lombok.extern.slf4j.Slf4j;



/**
 * @ClassName NettyClientHandler
 * @Description TODO
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/2 19:41
 */
@Slf4j
public class NettyClientHandler extends ChannelInboundHandlerAdapter {

    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        log.info("客户端Active .....");
    }

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        log.info("客户端收到消息: {}", ((MessageBase.Message)msg).getContent());
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        cause.printStackTrace();
        ctx.close();
    }
}
