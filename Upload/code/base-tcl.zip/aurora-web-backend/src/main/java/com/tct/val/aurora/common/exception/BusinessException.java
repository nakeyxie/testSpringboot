package com.tct.val.aurora.common.exception;


import com.tct.val.aurora.common.enums.ResponseCode;

/**
 * @ClassName BusinessException
 * @Description 业务异常
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021-5-27 14:24:56
 */
public class BusinessException extends RuntimeException {

	private static final long serialVersionUID = -1450841463269L;

	private Object[] messageArguments ;

	private int code;

	public BusinessException() {
	}

	public BusinessException(int code, String message) {
		super(message);
		this.code = code;
	}

	public BusinessException(ResponseCode errorCode) {
		this(errorCode.getCode(), errorCode.getMessage());
	}

	/**
	 * 业务异常不需要堆栈信息， 重写该方法以提高性能
	 * 前期先把堆栈信息输出
	 */
	/*@Override
	public synchronized Throwable fillInStackTrace() {
		return null;
	}*/

	public BusinessException(String message){
		super(message);
		this.code = ResponseCode.FAIL.getCode();
	}

	public Object[] getMessageArguments() {
		return messageArguments;
	}

	public void setMessageArguments(Object[] messageArguments) {
		this.messageArguments = messageArguments;
	}

	public int getCode() {
		return code;
	}
}
