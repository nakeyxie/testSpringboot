package com.tct.val.aurora.web;

import com.tct.val.aurora.common.enums.OsType;
import com.tct.val.aurora.common.enums.RegionType;
import com.tct.val.aurora.common.enums.UsageState;
import com.tct.val.aurora.entity.ClientInfo;
import com.tct.val.aurora.service.IClientInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


/**
 * @ClassName ClientInfoTest
 * @Description 测试客户端信息服务
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/9 10:28
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class ClientInfoTest {

    @Autowired
    IClientInfoService clientInfoService;

    @Test
    public void testAdd(){
        ClientInfo clientInfo = new ClientInfo();
        clientInfo.setClientId("789456");
        clientInfo.setConnected(Boolean.TRUE);
        clientInfo.setIpAddr("127.0.0.1");
        clientInfo.setMacAddr("456");
        clientInfo.setOsType(OsType.WINDOWS);
        clientInfo.setUserName("xcy");
        clientInfo.setPcName("xcy-pc");
        clientInfo.setRegion(RegionType.SZ);
        clientInfo.setVersionNum(200);
        clientInfo.setUsageState(UsageState.IDLE);
        clientInfoService.save(clientInfo);
        System.out.println("success");
    }

    @Test
    public void testQuery(){
        ClientInfo info = clientInfoService.getById("1402512222793592834");
        System.out.println(info.toString());
    }
}
