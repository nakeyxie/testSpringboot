package com.tct.val.aurora.common.utils;

import org.springframework.security.core.context.SecurityContextHolder;

/**
 * @ClassName AuthUitl
 * @Description 认证工具类
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/2 11:02
 */
public class AuthUitl {

    /**
     * @Description 获取当前登录用户名字
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021/6/2 11:04
     * @param
     * @return java.lang.String
    */
    public static String getCurrentUser(){
        return SecurityContextHolder.getContext().getAuthentication().getName();
    }
}
