package com.tct.val.aurora;

import com.tct.val.aurora.client.NettyClient;
import com.tct.val.aurora.server.MQSender;
import com.tct.val.aurora.util.PropertyUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.swing.plaf.synth.SynthOptionPaneUI;

@Slf4j
@SpringBootTest
class AuroraCmncApplicationTests {

    @Autowired
    private  PropertyUtil propertyUtil;

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Autowired
    private MQSender mqSender;

    @Test
    void contextLoads() {
        System.out.println("hello test");
    }

    @Test
    public void testConnect(){
        //启动netty客户端
        NettyClient nettyClient = new NettyClient();
        nettyClient.start();
    }

    @Test
    public void testGetVersion() throws InterruptedException {
        System.out.println("测试!");
        //System.out.println(PropertyUtil.getVersion());
        PropertyUtil p = new PropertyUtil();
        System.out.println("---");
        System.out.println("获取版本");
        System.out.println("版本:"+propertyUtil.getVersion());
        System.out.println("开始睡眠");
        Thread.sleep(2*60*1000);
        System.out.println("睡眠之后获取版本");
        System.out.println("版本:"+propertyUtil.getVersion());
    }

    /**
     * @Description 测试mq发送消息
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021/6/10 10:37
     * @param
     * @return void
    */
    @Test
    public void testMq(){
        String msg = "hello rabbitmq connect";
        String msg1 = "hello rabbitmq disConnect";
        rabbitTemplate.convertAndSend("clientExchange","client.connect",msg);
        rabbitTemplate.convertAndSend("clientExchange","client.disconnect",msg1);
        System.out.println("success");
    }

    /**
     * @Description 测试消息到exchange的回调
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021/6/10 10:37
     * @param
     * @return void
    */
    @Test
    public void testMqConfrim(){
        log.info("开始测试mq..........");
        //String msg = "我到exchange了";
        //mqSender.sendMessage("clientExchange","client.connect",msg,new CorrelationData("258"));
        //rabbitTemplate.convertAndSend("clientExchange","client.connect",msg,new CorrelationData("258"));

        String msg2 = "我到没到exchange";
        rabbitTemplate.convertAndSend("testExchange","client.connect",msg2,new CorrelationData("369"));
        //mqSender.sendMessage("testExchange","client.connect",msg2,new CorrelationData("369"));
    }

}
