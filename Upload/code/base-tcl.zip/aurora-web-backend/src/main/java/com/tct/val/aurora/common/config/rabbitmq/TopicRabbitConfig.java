package com.tct.val.aurora.common.config.rabbitmq;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @ClassName TopicRabbitConfig
 * @Description 消息队列配置
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/8 11:07
 */
@Configuration
@EnableRabbit
public class TopicRabbitConfig {

    //主题交换机
    @Bean
    public TopicExchange taskExchange() {
        return new TopicExchange("taskExchange", true, false);
    }

    // ----- 队列 -----
    @Bean
    public Queue taskQueue() {
        return new Queue("taskQueue", true);
    }


    /**
     * 绑定路由键为task.send
     */
    @Bean
    public Binding taskBinding() {
        return BindingBuilder.bind(taskQueue()).to(taskExchange()).with("task.send");
    }



}
