package com.tct.val.aurora.common.constant;

/**
 * @ClassName MqConstants
 * @Description mq队列相关常量
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021-6-16 09:11:12
 */
public class MqConstants {

    /**
     * @Description 交换机
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021/6/15 19:28
     */
    public static class Exchange{

        /**
         * 客户端相关交换机
         */
        public static final String CLIENT_EXCHANGE = "clientExchange";

        /**
         * 设备相关交换机
         */
        public static final String DEVICE_EXCHANGE = "deviceExchange";

    }



    /**
     * @Description 队列
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021/6/15 19:28
     */
    public static class Queue{

        /**
         * 客户端连接消息队列
         */
        public static final String CLIENT_CONNECT_QUEQUE = "clientConnectQueue";

        /**
         * 客户端断开连接消息队列
         */
        public static final String CLIENT_DISCONNECT_QUEQUE = "clientDisconnectQueue";

        /**
         * 新增或更新设备信息队列
         */
        public static final String DEVICEINFO_QUEQUE = "deviceInfoQueue";

        /**
         * 设备断开连接队列
         */
        public static final String DEVICE_DISCONNECT_QUEQUE = "deviceDisconnectQueue";


    }

    /**
     * @Description 路由键
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021/6/15 19:28
    */
    public static class RouteKey{

        /**
         * 客户端连接key
         */
        public static final String ROUTING_KEY_CLIENT_CONNECT = "client.connect";

        /**
         * 客户端断开连接key
         */
        public static final String ROUTING_KEY_CLIENT_DISCONNECT = "client.disconnect";

        /**
         * 新增或更新设备信息key
         */
        public static final String ROUTING_KEY_DEVICE_ADD_UPDATE = "device.add";

        /**
         * 设备断开连接
         */
        public static final String ROUTING_KEY_DEVICE_DISCONNECT = "device.disconnect";
    }
}
