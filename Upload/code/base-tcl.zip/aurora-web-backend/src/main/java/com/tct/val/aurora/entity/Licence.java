package com.tct.val.aurora.entity;

import lombok.Data;

/**
 * @ClassName Licence
 * @Description 客户端licence管理
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/8 16:13
 */
@Data
public class Licence extends BaseEntity{

    /**
     * 用户名
     */
    private String userName;

    /**
     * 邮箱
     */
    private String email;

    /**
     * 机器唯一码
     */
    private String machineId;

    /**
     * keyCode验证码
     */
    private String keyCode;

}
