package com.tct.val.aurora.web;

import com.tct.val.aurora.common.utils.RedisCache;
import com.tct.val.aurora.entity.SysUser;
import com.tct.val.aurora.service.ISysUserService;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;

/**
 * @ClassName TestRedis
 * @Description 测试缓存
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/5/29 14:37
 */

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class TestRedis extends AbstractTransactionalJUnit4SpringContextTests {

    @Autowired
    RedisCache redisCache;

    @Autowired
    ISysUserService userService;

    @Test
    public void testSet() {
        redisCache.setCacheObject("token","123456");
        System.out.println("ok");
        String token =redisCache.getCacheObject("token");
        System.out.println(token);
    }

    @Test
    public void testUserService(){
        SysUser userEntity = userService.findByUserName("nakey.xie");
        System.out.println(userEntity.toString());
    }
}
