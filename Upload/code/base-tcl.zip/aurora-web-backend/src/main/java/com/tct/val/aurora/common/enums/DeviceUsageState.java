package com.tct.val.aurora.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

/**
 * @EnumName DeviceUsageState
 * @Description 连接设备的使用状态
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/15 15:53
 */
@Slf4j
@Getter
public enum DeviceUsageState {


    IDLE(1, "空闲状态"),

    PREPARING(2, "测试准备中"),

    BUSY(3, "正在使用中")


    ;


    DeviceUsageState(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    @EnumValue
    private final Integer code;


    private final String msg;

    public static DeviceUsageState valueOf(Integer code) {
        if(code == null){
            return null;
        }
        for (DeviceUsageState type : DeviceUsageState.values()) {
            if (type.code.equals(code)) {
                return type;
            }
        }
        log.error("枚举转换失败,code:{}", code);
        return null;
    }
}
