package com.tct.val.aurora.vo.req;

import com.tct.val.aurora.entity.SysUser;
import lombok.Data;

import javax.validation.constraints.NotBlank;


/**
 * @ClassName SysUserParam
 * @Description 请求接收系统用户参数
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/5/31 16:37
 */
@Data
public class SysUserParam  extends SysUser {

    /**
     * 上传头像string
     */
    private String image;
}
