package com.tct.val.aurora.server;

import com.tct.val.aurora.protobuf.MessageBase;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.protobuf.ProtobufDecoder;
import io.netty.handler.codec.protobuf.ProtobufEncoder;
import io.netty.handler.codec.protobuf.ProtobufVarint32FrameDecoder;
import io.netty.handler.codec.protobuf.ProtobufVarint32LengthFieldPrepender;
import io.netty.handler.timeout.IdleStateHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


/**
 * @ClassName ServerInitializer
 * @Description TODO
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/2 19:19
 */
@Component
public class ServerInitializer extends ChannelInitializer<SocketChannel> {

    @Autowired
    NettyServerHandler nettyServerHandler;

    @Override
    protected void initChannel(SocketChannel socketChannel) throws Exception {
        //20秒没有收到消息 将IdleStateHandler 添加到 ChannelPipeline 中(空闲检测)
        socketChannel.pipeline().addLast("idleStateHandler", new IdleStateHandler(20, 0, 0));
        socketChannel.pipeline().addLast("idleStateTrigger", new ServerIdleStateTrigger());
        //解码时，解决粘包/半包的问题
        socketChannel.pipeline().addLast(new ProtobufVarint32FrameDecoder());
        //对接收到的信息，使用protobuf进行解码
        socketChannel.pipeline().addLast(new ProtobufDecoder(MessageBase.Message.getDefaultInstance()));
        //编码时，解决粘包/半包的问题
        socketChannel.pipeline().addLast(new ProtobufVarint32LengthFieldPrepender());
        //对于要发送的信息，使用protobuf进行编码
        socketChannel.pipeline().addLast(new ProtobufEncoder());
        socketChannel.pipeline().addLast(nettyServerHandler);

    }
}
