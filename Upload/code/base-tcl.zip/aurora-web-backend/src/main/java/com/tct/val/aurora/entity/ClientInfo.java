package com.tct.val.aurora.entity;


import lombok.Data;
import com.tct.val.aurora.common.enums.*;

/**
 * @ClassName Licence
 * @Description 客户端信息
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/8 16:13
 */
@Data
public class ClientInfo extends BaseEntity{

    /**
     * PC机的登录用户名
     */
    private String userName;

    /**
     * 客户端唯一凭证ID（licenceId）
     */
    private String clientId;

    /**
     * PC机的计算机全名
     */
    private String pcName;

    /**
     * PC机的IP地址
     */
    private String ipAddr;

    /**
     * PC机的MAC地址
     */
    private String macAddr;

    /**
     * PC机所处地区
     */
    private RegionType region;

    /**
     * PC机操作系统的类型
     */
    private OsType osType;

    /**
     * Client程序的版本号
     */
    private Integer versionNum;

    /**
     * Client是否连接通讯中心(0--否;1--是)
     */
    private Boolean connected;

    /**
     * Client的使用状态
     */
    private UsageState usageState;

}
