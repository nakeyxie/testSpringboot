package com.tct.val.aurora.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

/**
 * @EnumName RegionType
 * @Description 区域类型枚举
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/9 13:31
 */
@Slf4j
@Getter
public enum RegionType {

    SZ(1, "深圳"),

    HZ(2, "惠州"),

    CD(3, "成都"),

    NB(4, "宁波"),

    NJ(5, "南京"),

    US(6, "美国"),

    EU(7, "欧洲")

    ;


    RegionType(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    @EnumValue
    private final Integer code;


    private final String msg;

    public static RegionType valueOf(Integer code) {
        if(code == null){
            return null;
        }
        for (RegionType type : RegionType.values()) {
            if (type.code.equals(code)) {
                return type;
            }
        }
        log.error("枚举转换失败,code:{}", code);
        return null;
    }

}
