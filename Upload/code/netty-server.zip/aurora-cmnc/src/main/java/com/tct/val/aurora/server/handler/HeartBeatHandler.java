package com.tct.val.aurora.server.handler;

import com.tct.val.aurora.constant.Constants;
import com.tct.val.aurora.protobuf.MessageBase;
import com.tct.val.aurora.server.IBusinessHandler;
import com.tct.val.aurora.server.annotation.Command;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;


/**
 * @Description 心跳消息处理器
 * @Author R&D-VAL SZ nakey.xie
 * @Date  2021/6/7 19:15
 * @return
*/
@Component
@Slf4j
@Command(MessageBase.Message.CommandType.HEARTBEAT)
@ChannelHandler.Sharable
public class HeartBeatHandler implements IBusinessHandler {


	@Override
	public void process(MessageBase.Message message, Channel channel) {
		log.info("收到客户端发来的心跳消息：{}", message.getContent());
		//回应pong
		MessageBase.Message heartbeat = MessageBase.Message.newBuilder()
				.setCmd(MessageBase.Message.CommandType.HEARTBEAT)
				.setContent(Constants.PONG).build();
		channel.writeAndFlush(heartbeat);
	}
}
