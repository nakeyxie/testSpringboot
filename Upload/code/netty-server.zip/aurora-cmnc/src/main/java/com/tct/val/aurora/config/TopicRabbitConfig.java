package com.tct.val.aurora.config;

import com.tct.val.aurora.constant.MqConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @ClassName TopicRabbitConfig
 * @Description 消息队列配置
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/8 11:07
 */
@Slf4j
@Configuration
public class TopicRabbitConfig {

    @Autowired
    RabbitTemplate rabbitTemplate;

    //客户端主题交换机
    @Bean
    public TopicExchange clientExchange() {
        //第二个参数durable: 是否持久化, 第三个参数autoDelete: 当所有绑定队列都不再使用时, 是否自动删除交换器, true: 删除, false: 不删除
        return new TopicExchange(MqConstants.Exchange.CLIENT_EXCHANGE, true, false);
    }

    //设备相关主题交换机
    @Bean
    public TopicExchange deviceExchange() {
        return new TopicExchange(MqConstants.Exchange.DEVICE_EXCHANGE, true, false);
    }

    // ----- 队列 -----
    @Bean
    public Queue clientConnectQueue() {
        //queue的持久化, 声明队列时指定持久化参数durable为true即可
        return new Queue(MqConstants.Queue.CLIENT_CONNECT_QUEQUE, true);
    }

    @Bean
    Queue clientDisconnectQueue() {
        return new Queue(MqConstants.Queue.CLIENT_DISCONNECT_QUEQUE, true);
    }

    @Bean
    Queue deviceInfoQueue() {
        return new Queue(MqConstants.Queue.DEVICEINFO_QUEQUE, true);
    }

    @Bean
    Queue deviceDisConnectQueue() {
        return new Queue(MqConstants.Queue.DEVICE_DISCONNECT_QUEQUE, true);
    }



    /**
     * 绑定路由键为client.connect
     */
    @Bean
    public Binding connectBinding() {
        return BindingBuilder.bind(clientConnectQueue()).to(clientExchange()).with(MqConstants.RouteKey.ROUTING_KEY_CLIENT_CONNECT);
    }

    /**
     * 绑定路由键为client.disconnect规则
     */
    @Bean
    public Binding disconnectBinding() {
        return BindingBuilder.bind(clientDisconnectQueue()).to(clientExchange()).with(MqConstants.RouteKey.ROUTING_KEY_CLIENT_DISCONNECT);
    }


    /**
     * 绑定设备信息队列规则
     */
    @Bean
    public Binding deviceInfoBinding() {
        return BindingBuilder.bind(deviceInfoQueue()).to(deviceExchange()).with(MqConstants.RouteKey.ROUTING_KEY_DEVICE_ADD_UPDATE);
    }

    /**
     * 绑定设备断开连接队列规则
     */
    @Bean
    public Binding deviceDisconnectBinding() {
        return BindingBuilder.bind(deviceDisConnectQueue()).to(deviceExchange()).with(MqConstants.RouteKey.ROUTING_KEY_DEVICE_DISCONNECT);
    }



}
