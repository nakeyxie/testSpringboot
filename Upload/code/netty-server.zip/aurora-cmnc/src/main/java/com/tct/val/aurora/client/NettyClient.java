package com.tct.val.aurora.client;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.tct.val.aurora.model.ClientInfo;
import com.tct.val.aurora.protobuf.MessageBase;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;
import lombok.extern.slf4j.Slf4j;


/**
 * @ClassName NettyClient
 * @Description TODO
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/2 19:43
 */
@Slf4j
public class NettyClient {

    public void start() {
        EventLoopGroup group = new NioEventLoopGroup();
        Bootstrap bootstrap = new Bootstrap()
                .group(group)
                //该参数的作用就是禁止使用Nagle算法，使用于小数据即时传输
                .option(ChannelOption.TCP_NODELAY, true)
                .channel(NioSocketChannel.class)
                .handler(new NettyClientInitializer());

        try {
            ChannelFuture future = bootstrap.connect("127.0.0.1", 8888).sync();
            log.info("客户端连接成功....");
            log.info("发送连接消息:");
            ClientInfo info = new ClientInfo();
            info.setClientId("1402233049785155585");
            info.setVersionNum(200);
            info.setMacAddr("15f-df4-dafd54--554d");
            info.setIpAddr("127.0.0.1");
            info.setPcName("xcy");
            info.setUserName("xcy.nakey");
            info.setOsType("WINDOWS");
            info.setRegion("SZ");
            info.setUsageState("Idle");
            future.channel().writeAndFlush(MessageBase.Message.newBuilder()
                    .setClientId("1402233049785155585")
                    .setCmd(MessageBase.Message.CommandType.CLIENT_CONNECT)
                    .setContent(JSON.toJSONString(info)).build());
            // 等待连接被关闭
            future.channel().closeFuture().sync();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }finally {
            group.shutdownGracefully();
        }
    }
}
