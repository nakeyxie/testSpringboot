package com.tct.val.aurora.vo.resp;

import com.tct.val.aurora.common.enums.ResponseCode;
import lombok.Data;

import java.io.Serializable;

/**
 * @author changyaowu
 */
@Data
public class ResponseMessage<T> implements Serializable {


    /**
     * 错误码
     */
    private int code;
    /**
     * 返回消息
     */
    private String msg;
    /**
     * 数据
     */
    private T data;

    public ResponseMessage(int code, String msg, T data){
        this.code = code;
        this.msg = msg;
        this.data = data;
    }
    public ResponseMessage(T data){
        this.code = ResponseCode.SUCCESS.getCode();
        this.msg = ResponseCode.SUCCESS.getMessage();
        this.data = data;
    }
    public ResponseMessage(){
        this.code = ResponseCode.SUCCESS.getCode();
        this.msg = ResponseCode.SUCCESS.getMessage();
        this.data = null;
    }
    public ResponseMessage(ResponseCode code) {
        this.code = code.getCode();
        this.msg = code.getMessage();
    }
    public ResponseMessage(int code, String msg){
        this.code = code;
        this.msg = msg;
        this.data = null;
    }


    public static ResponseMessage success(){
        return new ResponseMessage();
    }

    public static <T> ResponseMessage<T> success(T data) {
        return new ResponseMessage(data);
    }

    public static ResponseMessage error(int code, String message) {
        return new ResponseMessage(code, message);
    }

    public static ResponseMessage error(String message) {
        return new ResponseMessage(ResponseCode.FAIL.getCode(), message);
    }

    public static <T> ResponseMessage<T> error(int code, String message, T data) {
        return new ResponseMessage(code, message, data);
    }

}
