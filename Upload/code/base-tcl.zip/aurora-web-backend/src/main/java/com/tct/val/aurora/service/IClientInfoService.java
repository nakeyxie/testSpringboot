package com.tct.val.aurora.service;



import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.tct.val.aurora.entity.ClientInfo;
import com.tct.val.aurora.entity.SysUser;
import com.tct.val.aurora.vo.req.ClientInfoPageQuery;


/**客户端信息服务
 * @author R&D-VAL SZ nakey.xie
 * @date 2021-6-9 10:26:54
 */
public interface IClientInfoService extends IService<ClientInfo> {

    /**
     * @Description 根据客户端ID查询客户端信息
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021/6/9 10:39
     * @param clientId
     * @return com.tct.val.aurora.model.ClientInfo
    */
    ClientInfo findByClientId(String clientId);


    /**
     * @Description 根据客户端ID更新客户端新
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021/6/9 11:06
     * @param clientInfo
     * @return void
    */
    void updateByClientId(ClientInfo clientInfo);

    /**
     * @Description 分页查询客户端信息
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021/6/15 13:44
     * @param clientInfoPageQuery
     * @return com.baomidou.mybatisplus.core.metadata.IPage<com.tct.val.aurora.entity.SysUser>
    */
    IPage<ClientInfo> queryPage(ClientInfoPageQuery clientInfoPageQuery);
}
