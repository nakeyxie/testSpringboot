package com.tct.val.aurora.server.handler;

import com.tct.val.aurora.protobuf.MessageBase;
import com.tct.val.aurora.server.IBusinessHandler;
import com.tct.val.aurora.server.annotation.Command;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * @ClassName HandlerFactory
 * @Description 处理器工厂
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/7 19:23
 */
@Component
@Slf4j
public class HandlerFactory implements ApplicationContextAware {

    private final Map<MessageBase.Message.CommandType, Object> beanMap;

    public HandlerFactory(){
        this.beanMap = new HashMap<>();
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        Map beanMap = applicationContext.getBeansOfType(IBusinessHandler.class);
        for (Object bean : beanMap.values()) {
            Command command = bean.getClass().getAnnotation(Command.class);
            if (command == null) {
                throw new RuntimeException(bean.getClass() + "has not Annotation @Command");
            }
            if (command.value().length == 0) {
                throw new RuntimeException(bean.getClass() + "@Command is empty");
            }
            MessageBase.Message.CommandType[] commands = command.value();
            this.beanMap.put(commands[0], bean);
        }
    }

    public IBusinessHandler getHandler(MessageBase.Message.CommandType type) {
        IBusinessHandler handler = (IBusinessHandler) beanMap.get(type);
        if (handler == null) {
            log.error("handler is null, type:{}", type);
        }
        return handler;
    }
}
