package com.tct.val.aurora.consumer;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.rabbitmq.client.Channel;
import com.tct.val.aurora.common.constant.MqConstants;
import com.tct.val.aurora.common.exception.BusinessException;
import com.tct.val.aurora.common.utils.AckUtils;
import com.tct.val.aurora.entity.DeviceInfo;
import com.tct.val.aurora.service.IDeviceInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

/**
 * @ClassName DeviceInfoConsumer
 * @Description 设备相关队列消息订阅
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021-6-15 20:30:41
 */
@Slf4j
@Component
public class DeviceInfoConsumer {

    @Autowired
    IDeviceInfoService deviceInfoService;

    /**
     * @Description 1.客户端连接成功，上传连接设备数据
     *              2.设备连上客户端PC,上传设备数据
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021-6-16 10:40:25
    */
    @RabbitHandler
    @RabbitListener(queues = MqConstants.Queue.DEVICEINFO_QUEQUE)
    @Transactional(rollbackFor = Exception.class)
    public void processConnect(Channel channel, String msg, Message message, @Headers Map<String, Object> map) {
        log.info("订阅设备数据消息:{}", msg);
        try {
            List<DeviceInfo> deviceInfos = JSON.parseArray(msg, DeviceInfo.class);
            deviceInfos.stream().forEach(deviceInfo -> {
                deviceInfo.setConnected(Boolean.TRUE);
                DeviceInfo existDevice = deviceInfoService.findBySnNum(deviceInfo.getSnNum());
                if (ObjectUtil.isNotNull(existDevice)) {
                    deviceInfo.setId(existDevice.getId());
                    deviceInfoService.updateById(deviceInfo);
                } else {
                    deviceInfoService.save(deviceInfo);
                }
            });
        } catch (Exception e) {
            log.error("处理设备数据消息异常", e);
            throw new BusinessException("处理设备数据消息异常!");
        } finally {
            AckUtils.ack(channel, message, map);
        }
    }

      /**
     * @Description 监听设备断开连接的消息
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021/6/15 15:30
     * @param channel
     * @param msg
     * @param message
     * @param map
     * @return void
    */
    @RabbitHandler
    @RabbitListener(queues = MqConstants.Queue.DEVICE_DISCONNECT_QUEQUE)
    public void processDisConnect(Channel channel, String msg, Message message, @Headers Map<String, Object> map) {
        log.info("订阅设备断开连接消息:{}", msg);
        if (StrUtil.isNotBlank(msg)) {
            DeviceInfo deviceInfo = new DeviceInfo();
            deviceInfo.setSnNum(msg);
            deviceInfo.setConnected(Boolean.FALSE);
            deviceInfoService.updateBySnNum(deviceInfo);
        }
        AckUtils.ack(channel, message, map);
    }
}
