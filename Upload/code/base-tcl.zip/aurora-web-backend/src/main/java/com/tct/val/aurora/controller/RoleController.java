package com.tct.val.aurora.controller;


import com.tct.val.aurora.vo.resp.ResponseMessage;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @author R&D-VAL SZ changyaowu
 * @date 2021/5/12 17:49
 */
@Controller
@RequestMapping("role")
public class RoleController {

    @GetMapping("queryRole")
    @ResponseBody
    public ResponseMessage queryRole() {

        return new ResponseMessage();
    }
}
