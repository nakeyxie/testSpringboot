package com.tct.val.aurora.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

/**
 * @EnumName UsageState
 * @Description 客户端使用状态枚举
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/9 13:31
 */
@Slf4j
@Getter
public enum UsageState {

    IDLE(1, "空闲状态"),

    TESTING(2, "正在执行测试任务")


    ;


    UsageState(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    @EnumValue
    private final Integer code;


    private final String msg;

    public static UsageState valueOf(Integer code) {
        if(code == null){
            return null;
        }
        for (UsageState type : UsageState.values()) {
            if (type.code.equals(code)) {
                return type;
            }
        }
        log.error("枚举转换失败,code:{}", code);
        return null;
    }


}
