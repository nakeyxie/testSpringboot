package com.tct.val.aurora.controller;


import cn.hutool.core.codec.Base64Decoder;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.tct.val.aurora.common.exception.BusinessException;
import com.tct.val.aurora.common.utils.AuthUitl;
import com.tct.val.aurora.common.utils.BeanHelper;
import com.tct.val.aurora.entity.SysUser;
import com.tct.val.aurora.service.ISysUserService;
import com.tct.val.aurora.vo.req.SysUserPageQuery;
import com.tct.val.aurora.vo.req.SysUserParam;
import com.tct.val.aurora.vo.resp.ResponseMessage;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;


/**
 * @ClassName etstController
 * @Description 用户管理
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/5/27 13:42
 */
@Api("用户管理")
@RestController
@RequestMapping("/sysUser")
public class SysUserController {

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Autowired
    ISysUserService userService;

    /**
     * 分页查询用户信息
     */
    @ApiOperation("分页查询用户信息")
    @GetMapping("/page")
    public ResponseMessage queryPage(SysUserPageQuery sysUserPageQuery){
        IPage<SysUser> userPage = userService.queryPage(sysUserPageQuery);
        return ResponseMessage.success(userPage);

    }

    /**
     * 查询用户信息
     */
    @ApiOperation("获取用户信息")
    @GetMapping("/info")
    public ResponseMessage queryUser() {
        String username = AuthUitl.getCurrentUser();
        if (StringUtils.isBlank(username)) {
            throw new BusinessException("用户未登陆!");
        }
        SysUser user = userService.findByUserName(username);
        return ResponseMessage.success(user);
    }


    /**
     * 上传头像
     */
    @ApiOperation("上传头像")
    @PostMapping("/icon")
    public ResponseMessage uploadIcon(String icon) {
        if (StringUtils.isBlank(icon)) {
            throw new BusinessException("icon为空!");
        }
        byte[] iconBytes = Base64Decoder.decode(icon);
        SysUser user = new SysUser();
        user.setIcon(iconBytes);
        String userName = AuthUitl.getCurrentUser();
        user.setUserName(userName);
        userService.updateByName(user);
        return ResponseMessage.success();
    }


    /**
     * 增加用户
     */
    @ApiOperation("增加用户")
    @PostMapping("/user")
    public ResponseMessage addUser(@Valid @RequestBody  SysUserParam userParam) {
        SysUser sysUser = BeanHelper.copyProperties(userParam, SysUser.class);
        //密码加密
        sysUser.setPassword(passwordEncoder.encode(userParam.getPassword()));
        //头像BASE64编码
        sysUser.setIcon( Base64Decoder.decode(userParam.getImage()));
        userService.save(sysUser);
        return ResponseMessage.success();
    }

    /**
     * 删除用户
     */
    @ApiOperation("删除用户")
    @PostMapping("/user/delete/{id}")
    public ResponseMessage deleteUser(@PathVariable("id") String id) {
        if (StringUtils.isBlank(id)) {
            throw new BusinessException("id为空!");
        }
        userService.removeById(id);
        return ResponseMessage.success();
    }

    /**
     * 修改用户
     */
    @ApiOperation("修改用户")
    @PutMapping("/user")
    public ResponseMessage modifyUser(@RequestBody SysUserParam userParam) {
        if(StringUtils.isBlank(userParam.getId())){
            throw new BusinessException("id为空，无法更新!");
        }
        SysUser toUpdateUser = BeanHelper.copyProperties(userParam, SysUser.class);
        if(StringUtils.isNotBlank(userParam.getImage())){
            toUpdateUser.setIcon(Base64Decoder.decode(userParam.getImage()));
        }
        userService.update(toUpdateUser);
        return ResponseMessage.success();
    }
}
