package com.tct.val.aurora.common.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.ldap.core.AuthenticationSource;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;

/**
 * @author R&D-VAL SZ changyaowu
 * @date 2021/5/11 21:02
 */
@Configuration
public class LdapConfiguration {

    @Value("${ldap.url}")
    private String url;

    @Value("${ldap.password}")
    private String password;

    @Value("${ldap.dn}")
    private String dn;

    @Bean
    public LdapTemplate ldapTemplate() {
        LdapContextSource ls = new LdapContextSource();
        ls.setCacheEnvironmentProperties(false);
        ls.setUrl(url);
        ls.setAuthenticationSource(new AuthenticationSource() {
            @Override
            public String getCredentials() {
                return password;
            }

            @Override
            public String getPrincipal() {
                return dn;
            }
        });
        return new LdapTemplate(ls);
    }

}
