package com.tct.val.aurora.service;



import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.tct.val.aurora.entity.SysUser;
import com.tct.val.aurora.vo.req.SysUserPageQuery;


import java.util.List;

/**系统用户服务
 * @author R&D-VAL SZ changyaowu
 * @date 2021/5/11 20:52
 */
public interface ISysUserService  extends IService<SysUser> {



    /**
     * update
     * @param user
     */
    void update(SysUser user);
    /**
     *  all
     * @return
     */
    List<SysUser> findByAll();

    /**
     * 根据用户名查询用户对象
     * @param userName
     * @return
     */
    SysUser findByUserName(String userName);

    /**
     * @Description 根据用户名删除用户（更改状态）
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021/5/27 17:09
     * @param
     * @return void
    */
    void delUserByName(String userName);

    /**
     * @Description 根据用户名更新用户头像
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021/5/27 18:06
     * @param user
     * @return void
    */
    void updateByName(SysUser user);

    IPage<SysUser> queryPage(SysUserPageQuery sysUserPageQuery);
}
