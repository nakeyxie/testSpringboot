package com.tct.val.aurora.common.config.security;


import com.tct.val.aurora.common.utils.LdapSearchUtils;
import com.tct.val.aurora.entity.SysUser;
import com.tct.val.aurora.service.ISysUserService;
import com.tct.val.aurora.vo.LdapUser;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class LoginAuthenticationProvider implements AuthenticationProvider {

    @Autowired
    private LdapSearchUtils ldapSearchUtils;

    @Autowired
    private ISysUserService userService;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Autowired
    private UserDetailsService userDetailsService;


    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        String username = authentication.getName();
        String password = authentication.getCredentials().toString();
        if(StringUtils.isBlank(username) || StringUtils.isBlank(password)){
            throw new BadCredentialsException("用户名或者密码为空!");
        }

        SysUser user = userService.findByUserName(username);

        // 首次登陆
        if (null == user) {
            if (!ldapSearchUtils.authenticate(username, password)) {
                throw new InternalAuthenticationServiceException("该域账号不存在，请联系管理员添加！");
            }
            LdapUser ldapUser = ldapSearchUtils.searchByName(username);

            userService.save(new SysUser(
                    username,
                    passwordEncoder.encode(password),
                    ldapUser.getMail()
            ));
        } else {
            //密码验证不通过
            if (!passwordEncoder.matches(password, user.getPassword())) {
                if (!ldapSearchUtils.authenticate(username, password)) {
                    throw new BadCredentialsException("账号或密码错误！");
                }
                user.setPassword(passwordEncoder.encode(password));
                //修改密码
                userService.update(user);
            }
            //检查用户的激活状态
            if(Boolean.FALSE.equals(user.getActive())){
                throw new InternalAuthenticationServiceException("该域账号处于禁用状态!");
            }
        }
        UserDetails userDetails = userDetailsService.loadUserByUsername(username);
        UsernamePasswordAuthenticationToken authenticationtoken = new UsernamePasswordAuthenticationToken(userDetails, authentication.getCredentials(), userDetails.getAuthorities());

        return authenticationtoken;
    }

    @Override
    public boolean supports(Class<?> aClass) {
        return true;
    }
}
