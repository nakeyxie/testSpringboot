package com.tct.val.aurora.util;

import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.tct.val.aurora.constant.MqConstants;
import com.tct.val.aurora.protobuf.MessageBase;
import com.tct.val.aurora.server.MQSender;
import io.netty.channel.Channel;
import io.netty.channel.ChannelId;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;
import io.netty.util.AttributeKey;
import io.netty.util.concurrent.GlobalEventExecutor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 使用ChannelGroup和Map共同维护Channel，
 * 当用户第一次连接的时候，才会将对应的参数（clientId,channelID）放置map集合中，代表该Channel已认证(用户已登录)，未登录的用户不能处理业务
 */
@Slf4j
@Component
public class ChannelUtil {

    @Autowired
    private PropertyUtil propertyUtil;

    @Autowired
    private MQSender mqSender;

    /**
     * 连接通道集合
     */
    public static ChannelGroup channels = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);
    /**
     * key:clientId,value:ChannelId
     * 保存建立连接的客户端
     */
    public static Map<String, ChannelId> channelIdMap = new ConcurrentHashMap<>();

    AttributeKey<String> CID = AttributeKey.valueOf("clientId");


    /**
     * 客户端连接服务端时调用，用于保存Channel连接
     * @param channel
     */
    public void channelAdded(Channel channel) {
        log.info("已添加id为: "+channel.id().asShortText()+" 到Channel组中");
        channels.add(channel);
    }

    /**
     * 客户端与服务端断开连接时调用，用于清除Channel连接
     * 当客户端主动调用断开连接时，会两次调用此方法
     * @param channel
     */
    public void channelReomved(Channel channel) {
        channels.remove(channel);
        String clientId = channel.attr(CID).get();
        if (null != clientId && channelIdMap.containsKey(clientId)) {
            channelIdMap.remove(clientId);
            //后端数据库状态更改
            mqSender.sendMessage(MqConstants.Exchange.CLIENT_EXCHANGE,MqConstants.RouteKey.ROUTING_KEY_CLIENT_DISCONNECT,clientId);
        }
        log.info("channelIdMap size :"+channelIdMap.size());

    }

    /**
     * 客户端对连接进行认证
     * 认证成功返回clientId
     * @param channel
     * @param message
     * @return
     */
    public String channelAuthentication(Channel channel, MessageBase.Message message) {
        log.info("客户端连接认证...");
        String clientId = null;
        try {
            String content = message.getContent();
            JSONObject obj = JSON.parseObject(content);
            Integer clientVersion = (Integer) obj.get("versionNum");
            //最低版本要求
            int minimumVersion = propertyUtil.getVersion();
            if (clientVersion >= minimumVersion) {
                log.info("客户端连接认证成功");
                clientId =message.getClientId();
                ChannelId channelId = channelIdMap.get(clientId);
                if (ObjectUtil.isNotNull(channelId)) {
                    //根据channelId和channel删除都可以
                    channels.remove(channelId);
                }
                channelIdMap.put(clientId, channel.id());
                channels.find(channel.id()).attr(CID).set(clientId);
            }
        } catch (Exception e) {
            log.error("认证异常:{}", e.getMessage(), e);
        }
        return clientId;
    }


    public boolean checkChannelAuthentication(Channel channel) {
        String clientId = channel.attr(CID).get();
        ChannelId realChannelId = channelIdMap.get(clientId);
        if (ObjectUtil.isNotNull(realChannelId)) {
            ChannelId channelId = channel.id();
            return realChannelId.asShortText().equals(channelId.asShortText()) ? true : false;
        } else {
            return false;
        }
    }

    public boolean sendMsg(String clientId ,String msg, MessageBase.Message.CommandType type) {
        ChannelId channelId=channelIdMap.get(clientId);
        if (null!=channelId) {
            MessageBase.Message response = MessageBase.Message.newBuilder().setCmd(type).setContent(msg).build();
            channels.find(channelId).writeAndFlush(response);
            return true;
        }
        return false;
    }

    public void sendMsg(Channel  channel , MessageBase.Message message){
        channel.writeAndFlush(message);
    }



    public static String getIp(Channel channel) {
        String address = channel.remoteAddress().toString();
        address = address.replaceAll("/","");
        return address.split(":")[0];
    }

    public int getChannelsSize() {
        return channels.size();
    }

    public static Set<String> getKeys(){
        return channelIdMap.keySet();
    }




}
