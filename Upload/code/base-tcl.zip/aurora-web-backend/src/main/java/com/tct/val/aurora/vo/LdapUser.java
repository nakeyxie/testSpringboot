package com.tct.val.aurora.vo;

import lombok.Data;

/**
 * @author R&D-VAL SZ changyaowu
 * @date 2021/5/12 10:36
 */
@Data
public class LdapUser {

    private String displayname;

    private String givenname;

    private String samaccounttype;

    private String primarygroupid;

    private String company;

    private String objectclass;

    private String objectcategory;

    private String cn;

    private String useraccountcontrol;

    private String telephonenumber;

    private String pager;

    private String userprincipalname;

    private String physicaldeliveryofficename;

    private String manager;

    private String description;

    private String mail;


}
