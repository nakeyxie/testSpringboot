package com.tct.val.aurora.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import com.tct.val.aurora.entity.Licence;
import org.apache.ibatis.annotations.Param;

/**
 * @InterfaceName SysUserMapper
 * @Description 系统用户dao
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/5/31 10:02
 */
public interface LicenceMapper extends BaseMapper<Licence> {


}
