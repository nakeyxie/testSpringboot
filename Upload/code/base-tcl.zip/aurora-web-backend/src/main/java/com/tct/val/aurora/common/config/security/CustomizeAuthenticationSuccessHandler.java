package com.tct.val.aurora.common.config.security;

import com.alibaba.fastjson.JSON;

import com.tct.val.aurora.service.TokenService;
import com.tct.val.aurora.vo.LoginUser;
import com.tct.val.aurora.vo.resp.ResponseMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;
import com.tct.val.aurora.common.enums.ResponseCode;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @Author: wcy
 * @Date: 2020/9/22 9:02 上午
 * 登录成功处理逻辑
 */
@Component
public class CustomizeAuthenticationSuccessHandler implements AuthenticationSuccessHandler {

    @Autowired
    private TokenService tokenService;

    @Override
    public void onAuthenticationSuccess(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Authentication authentication) throws IOException, ServletException {

        ResponseMessage<String> responseMessage = new ResponseMessage<>(ResponseCode.SUCCESS);

        LoginUser userDetails = (LoginUser) authentication.getPrincipal();
        //responseMessage.setData(TokenUtil.createJwtToken(userDetails));
        responseMessage.setData(tokenService.createToken(userDetails));
        httpServletResponse.setContentType("text/json;charset=utf-8");
        httpServletResponse.getWriter().write(JSON.toJSONString(responseMessage));

    }

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, FilterChain chain, Authentication authentication) throws IOException, ServletException {

    }
}
