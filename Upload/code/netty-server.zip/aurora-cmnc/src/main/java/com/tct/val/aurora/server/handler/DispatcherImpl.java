package com.tct.val.aurora.server.handler;

import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.tct.val.aurora.constant.Constants;
import com.tct.val.aurora.protobuf.MessageBase;
import com.tct.val.aurora.server.IBusinessHandler;
import com.tct.val.aurora.server.IDispatcher;
import com.tct.val.aurora.server.handler.HandlerFactory;
import com.tct.val.aurora.util.ChannelUtil;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

/**
 * @ClassName Dispatcher
 * @Description 处理器分发实现类
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/7 19:19
 */
@Slf4j
@Component
@ChannelHandler.Sharable
public class DispatcherImpl  implements IDispatcher {

    @Autowired
    HandlerFactory handlerFactory;

    @Autowired
    ChannelUtil channelUtil;

    @Override
    public void dispatcher(MessageBase.Message message, Channel channel) {
        try {
            MessageBase.Message.CommandType commandType = message.getCmd();

            log.info("进行消息分发处理,cmd:{},content:{}", commandType, message.getContent());
            //检验
            if(ObjectUtil.isNull(commandType)){
                channel.writeAndFlush(MessageBase.Message.newBuilder().setCmd(message.getCmd()).setContent("业务类型为空!").build());
                throw new RuntimeException("业务类型为空!");
            }
            //非业务类型(心跳，客户端连接)
            List<MessageBase.Message.CommandType> noBusinessTypes = Arrays.asList(MessageBase.Message.CommandType.HEARTBEAT, MessageBase.Message.CommandType.CLIENT_CONNECT);
            if(!noBusinessTypes.contains(commandType)){
                boolean pass = channelUtil.checkChannelAuthentication(channel);
                if(!pass){
                    JSONObject object = new JSONObject();
                    //认证失败
                    object.put(Constants.AUTH_PASS,false);
                    String response = object.toJSONString();
                    channel.writeAndFlush(MessageBase.Message.newBuilder().setCmd(message.getCmd()).setContent(response).build());
                    throw new RuntimeException("连接认证异常，不做业务处理!");
                }
            }
            //分发处理
            IBusinessHandler handler = handlerFactory.getHandler(commandType);
            handler.process(message, channel);
        } catch (Exception e) {
            log.error("消息处理异常：{}",e.getMessage(),e);
        }
    }
}
