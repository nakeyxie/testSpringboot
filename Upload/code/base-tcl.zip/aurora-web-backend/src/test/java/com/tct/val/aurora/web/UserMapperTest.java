package com.tct.val.aurora.web;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import com.tct.val.aurora.entity.SysUser;
import com.tct.val.aurora.mapper.SysUserMapper;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@SuppressWarnings("SpringJavaInjectionPointsAutowiringInspection")
@RunWith(SpringRunner.class)
@SpringBootTest
@Slf4j
public class UserMapperTest {
    @Autowired
    SysUserMapper userMapper;

    @Test
    public void select() {
        List<SysUser> list = userMapper.selectList(null);
        list.forEach(System.out::println);
    }

    @Test
    public void insert(){
        SysUser user = new SysUser();
        user.setUserName("testlog1");
        user.setPassword("testlog1");
        userMapper.insert(user);
        System.out.println("主键:"+user.getId());
    }

    @Test
    public void page(){
        IPage<SysUser> userPage = userMapper.selectPage(new Page(0,2),null);
        System.out.println(JSONObject.toJSON(userPage));
    }

    @Test
    public void update(){
        SysUser sysUser = new SysUser();
        sysUser.setId("1399234941090381825");
        sysUser.setUserName("testUpdate");
        userMapper.updateById(sysUser);
    }

    @Test
    public void delete(){
        SysUser sysUser = new SysUser();
        sysUser.setId("1399234941090381825");
        userMapper.deleteById(sysUser);

        //删除后查询
        SysUser sysUser1 = userMapper.selectById("1399234941090381825");
        System.out.println("删除后:"+sysUser1);
    }

    @Test
    public void deleteWithfill(){
        SysUser sysUser = new SysUser();
        sysUser.setId("1399232876523880450");
        userMapper.deleteByIdWithFill(sysUser);
    }

    /**
     * @Description 测试原生xml写法是否生效
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021/5/31 15:13
     * @param
     * @return void
    */
    @Test
    public void updateByName(){
        SysUser sysUser = new SysUser();
        sysUser.setUserName("test3");
        sysUser.setEmail("123@11.com");
        userMapper.updateByName(sysUser.getEmail(), sysUser.getUserName());

    }

    @Test
    public void testLogback(){
        log.debug("我是debug！");
        log.info("我是info!");
        log.error("我是error!");
        log.trace("我是trace!");
        log.warn("我是warn!");
    }


}