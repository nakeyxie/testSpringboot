package com.tct.val.aurora.server;

import com.tct.val.aurora.protobuf.MessageBase;
import com.tct.val.aurora.server.handler.DispatcherImpl;
import com.tct.val.aurora.util.ChannelUtil;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @ClassName NettyServerHandler
 * @Description 消息处理器
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/2 19:24
 */
@Slf4j
@Component
@ChannelHandler.Sharable
public class NettyServerHandler  extends SimpleChannelInboundHandler<MessageBase.Message> {

    @Autowired
    private ChannelUtil channelUtil;

    @Autowired
    private DispatcherImpl dispatcher;



    @Override
    protected void channelRead0(ChannelHandlerContext ctx, MessageBase.Message msg) throws Exception {
        dispatcher.dispatcher(msg, ctx.channel());
    }

    @Override
    public void handlerAdded(ChannelHandlerContext ctx) throws Exception { // (2)
        Channel incoming = ctx.channel();
        log.info("add connect:" + incoming.remoteAddress());
        channelUtil.channelAdded(incoming);
    }

    @Override
    public void handlerRemoved(ChannelHandlerContext ctx) throws Exception { // (3)
        Channel incoming = ctx.channel();
        log.info("remove connect:" + incoming.remoteAddress());
        channelUtil.channelReomved(incoming);
    }

    /**
     * 当从Channel中读数据时被调用
     */
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        super.channelRead(ctx, msg);
    }

    /**
     * 当Channel变成活跃状态时被调用；Channel是连接/绑定、就绪的
     */
    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        Channel incoming = ctx.channel();
        log.info("channelActive:" + incoming.remoteAddress() + "在线");
    }

    /**
     * Channel未连接到远端
     */
    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception { // (6)
        Channel incoming = ctx.channel();
        log.info("channelInactive:" + incoming.remoteAddress() + "掉线");
        incoming.close();
        ctx.close();
    }

    /**
     * @Description 读取客户端消息完成
     * @Author R&D-VAL SZ nakey.xie
     * @Date  2021/6/7 20:11
     * @param ctx
     * @return void
    */
    @Override
    public void channelReadComplete(ChannelHandlerContext ctx) throws Exception {
        //log.info("读取客户端消息完成");
        super.channelReadComplete(ctx);
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        Channel incoming = ctx.channel();
        ctx.close();
        log.error("exceptioncaught," + incoming.remoteAddress(), cause);
    }


}
