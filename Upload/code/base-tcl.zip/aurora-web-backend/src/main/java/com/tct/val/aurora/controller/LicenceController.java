package com.tct.val.aurora.controller;


import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.tct.val.aurora.common.exception.BusinessException;
import com.tct.val.aurora.entity.Licence;
import com.tct.val.aurora.vo.resp.LicenceVO;
import com.tct.val.aurora.vo.resp.ResponseMessage;

import com.tct.val.aurora.common.utils.DesDUtil;


import com.tct.val.aurora.service.ILicenceService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


/**
 * @ClassName etstController
 * @Description 客户端授权码管理
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/5/27 13:42
 */
@Api("客户端授权码管理管理")
@RestController
@RequestMapping("/licence")
public class LicenceController {



    @Autowired
    ILicenceService licenceService;


    /**
     * 分页查询用户信息
     */
    @ApiOperation("生成授权码")
    @GetMapping("/gen")
    public ResponseMessage genKey(String email, String userName, String machineId) {
        if (StrUtil.isBlank(email) || StrUtil.isBlank(userName) || StrUtil.isBlank(machineId)) {
            throw new BusinessException("请求参数为空!");
        }
        LicenceVO result = new LicenceVO();
        Licence exist = licenceService.getByMachineId(machineId);
        if(ObjectUtil.isNotNull(exist)){
            String keyCode = exist.getKeyCode();
            result.setIsNew(false);
            result.setKeyCode(keyCode);
        }else{
            Licence licence = new Licence();
            licence.setEmail(email);
            licence.setUserName(userName);
            licence.setMachineId(machineId);
            licenceService.save(licence);
            String keyCode = generateKey(licence);
            licence.setKeyCode(keyCode);
            licenceService.updateById(licence);
            result.setIsNew(true);
            result.setKeyCode(keyCode);

        }
        return ResponseMessage.success(result);
    }

    private String generateKey(Licence licence) {
        String sourceStr = licence.getId()+DesDUtil.spilt+licence.getMachineId();
        String keyCode = DesDUtil.encryptDES(sourceStr);
       /* System.out.println("keyCode"+keyCode);
        System.out.println("解密:");
        System.out.println(DesDUtil.decryptDES(keyCode));*/
        return keyCode;
    }
}
