package com.tct.val.aurora.common.utils;

import com.rabbitmq.client.Channel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.support.AmqpHeaders;

import java.io.IOException;
import java.util.Map;

/**
 * @Description 手动ACK实现消息确认机制工具类
 * @Author R&D-VAL SZ nakey.xie
 * @Date  2021/6/10 15:45
 * @return
*/
@Slf4j
public class AckUtils {

    public static void ack(Channel channel, Message message, Map<String, Object> map) {
        if (map.get("error") != null) {
            log.info("错误的消息");
            try {
                //否认消息,拒接该消息重回队列
                channel.basicNack((Long) map.get(AmqpHeaders.DELIVERY_TAG), false, false);
                return;
            } catch (IOException e) {
                log.error("处理错误消息失败!", e);
            }
        }
        //手动ACK
        //默认情况下如果一个消息被消费者所正确接收则会被从队列中移除
        //如果一个队列没被任何消费者订阅，那么这个队列中的消息会被 Cache（缓存），
        //当有消费者订阅时则会立即发送，当消息被消费者正确接收时，就会被从队列中移除
        try {
            //手动ack应答
            //告诉服务器收到这条消息 已经被我消费了 可以在队列删掉 这样以后就不会再发了
            // 否则消息服务器以为这条消息没处理掉 后续还会在发，true确认所有消费者获得的消息
            channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
            log.info("消息消费成功：序列id：{},消息ID:{}", message.getMessageProperties().getDeliveryTag(),
                    message.getMessageProperties().getHeaders().get("spring_returned_message_correlation"));
        } catch (IOException e) {
            log.error("消息消费失败：序列id：{},消息ID:{}", message.getMessageProperties().getDeliveryTag(),
                    message.getMessageProperties().getHeaders().get("spring_returned_message_correlation"), e);
            //丢弃这条消息
            try {
                //最后一个参数是：是否重回队列
                channel.basicNack(message.getMessageProperties().getDeliveryTag(), false, false);
            } catch (IOException e1) {
                log.error("处理失败!!!", e1);
            }
        }
    }
}
