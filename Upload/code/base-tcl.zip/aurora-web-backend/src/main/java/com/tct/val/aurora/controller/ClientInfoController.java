package com.tct.val.aurora.controller;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.tct.val.aurora.entity.ClientInfo;
import com.tct.val.aurora.entity.SysUser;
import com.tct.val.aurora.service.IClientInfoService;
import com.tct.val.aurora.vo.req.ClientInfoPageQuery;
import com.tct.val.aurora.vo.resp.ResponseMessage;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


/**
 * @ClassName etstController
 * @Description 客户端信息管理
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/5/27 13:42
 */
@Api("客户端信息管理")
@RestController
@RequestMapping("/client")
public class ClientInfoController {


    @Autowired
    IClientInfoService  clientInfoService;

    /**
     * 分页查询客户端信息
     */
    @ApiOperation("分页查询客户端信息")
    @GetMapping("/page")
    public ResponseMessage queryPage(ClientInfoPageQuery clientInfoPageQuery){
        IPage<ClientInfo> clientInfoPage = clientInfoService.queryPage(clientInfoPageQuery);
        return ResponseMessage.success(clientInfoPage);

    }


}
