package com.tct.val.aurora.vo.resp;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.ToString;
import lombok.experimental.Accessors;
import org.springframework.security.core.GrantedAuthority;

import java.io.Serializable;
import java.util.Collection;

/**
 * @author
 */
@Data
@ToString
@Accessors(chain = true)
@ApiModel(value = "登录后token属性表",description = "登录后token属性表")
public class UserRoleVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 用户
     */
    private String username;

    /**
     * 用户唯一标识
     */
    private String token;
    /**
     * 登录时间
     */
    private Long loginTime;
    /**
     * 权限
     */
    private Collection<? extends GrantedAuthority> permissions;
    /**
     * 过期时间
     */
    private Long expireTime;

}
