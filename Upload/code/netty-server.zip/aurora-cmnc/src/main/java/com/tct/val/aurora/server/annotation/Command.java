package com.tct.val.aurora.server.annotation;

import com.tct.val.aurora.protobuf.MessageBase;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.TYPE;

/**
 * @Description 消息类型注解
 * @Author R&D-VAL SZ nakey.xie
 * @Date  2021/6/7 19:07
 * @return
*/
@Target(TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface Command {

    MessageBase.Message.CommandType[] value();

}
