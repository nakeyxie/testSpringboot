package com.tct.val.aurora.web;

import ch.qos.logback.core.net.SyslogOutputStream;
import com.tct.val.aurora.common.enums.DeviceUsageState;
import com.tct.val.aurora.common.enums.OsType;
import com.tct.val.aurora.common.enums.PlatformType;
import com.tct.val.aurora.common.enums.SwBuildType;
import com.tct.val.aurora.entity.DeviceInfo;
import com.tct.val.aurora.service.IDeviceInfoService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @ClassName DeviceInfoTest
 * @Description 设备相关测试
 * @Author R&D-VAL SZ nakey.xie
 * @Date 2021/6/15 20:42
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class DeviceInfoTest {

    @Autowired
    IDeviceInfoService deviceInfoService;



    @Test
    public void testAdd(){
        DeviceInfo device = new DeviceInfo();
        device.setClientId("123");
        device.setConnected(Boolean.TRUE);
        device.setMarketingName("marketName");
        device.setOsType(OsType.WINDOWS);
        device.setOsVersion("45");
        device.setPerso("perso");
        device.setPlatformType(PlatformType.QCT);
        device.setProductName("productName1");
        device.setProjectName("project1");
        device.setRamSize(1200);
        device.setRomSize(800);
        device.setScreenHeight(480);
        device.setScreenWidth(150);
        device.setShare(Boolean.FALSE);
        device.setSnNum("tml001");
        device.setSwBuildType(SwBuildType.APPLI);
        device.setSwVersion("1.0");
        device.setUsageState(DeviceUsageState.IDLE);
        device.setCreateBy("xcy");
        deviceInfoService.save(device);
        System.out.println("保存成功:"+device.getId());
    }
}
